<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM tasks WHERE id=?");
$stmt->execute([$id]);
$t = $stmt->fetch();

if ($t) {
    db()->prepare("DELETE FROM tasks WHERE id=?")->execute([$id]);
    logActivity('tasks','delete',"Deleted task: {$t['title']}");
    setFlash('success', 'Task deleted successfully.');
} else {
    setFlash('danger', 'Task not found.');
}

header('Location: '.BASE_URL.'/modules/tasks/index.php');
exit;
