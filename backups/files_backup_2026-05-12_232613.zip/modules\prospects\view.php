<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT l.*, u.name AS assigned_name, c.name as creator_name 
                      FROM leads l 
                      LEFT JOIN users u ON l.assigned_to = u.id 
                      LEFT JOIN users c ON l.created_by = c.id 
                      WHERE l.id = ? AND l.deleted_at IS NULL");
$stmt->execute([$id]);
$lead = $stmt->fetch();

if (!$lead) {
    setFlash('danger', 'Lead not found.');
    header("Location: index.php");
    exit;
}

// Fetch related data
$contacts = db()->prepare("SELECT * FROM lead_contacts WHERE lead_id = ? ORDER BY is_primary DESC");
$contacts->execute([$id]);
$contacts = $contacts->fetchAll();

$products = db()->prepare("SELECT product_name FROM lead_interested_products WHERE lead_id = ?");
$products->execute([$id]);
$products = $products->fetchAll(PDO::FETCH_COLUMN);

$meetings = db()->prepare("SELECT m.*, u.name as personnel_name FROM lead_meetings m LEFT JOIN users u ON m.meeting_with_id = u.id WHERE m.lead_id = ? ORDER BY m.created_at DESC");
$meetings->execute([$id]);
$meetings = $meetings->fetchAll();

$documents = db()->prepare("SELECT * FROM lead_documents WHERE lead_id = ? ORDER BY created_at DESC");
$documents->execute([$id]);
$documents = $documents->fetchAll();

$timeline = db()->prepare("SELECT t.*, u.name as user_name FROM lead_timeline t LEFT JOIN users u ON t.user_id=u.id WHERE lead_id = ? ORDER BY created_at DESC");
$timeline->execute([$id]);
$timeline = $timeline->fetchAll();

$pageTitle = 'View Lead: ' . e($lead['lead_code']);
include __DIR__ . '/../../includes/header.php'; ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>

<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Lead Detail</div>
</div>

<div class="page-content">
    <?= flashHtml() ?>
    
    <div class="page-header">
        <div class="page-header-left">
            <div class="d-flex align-items-center gap-3">
                <a href="index.php" class="btn btn-icon btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
                <div>
                    <h1 class="mb-0"><?= e($lead['company_name'] ?: 'No Company Name') ?></h1>
                    <div class="text-muted small"><?= e($lead['lead_code']) ?> • Created by <?= e($lead['creator_name']) ?> on <?= formatDate($lead['created_at']) ?></div>
                </div>
            </div>
        </div>
        <div class="page-header-right">
            <div class="d-flex gap-2">
                <a href="edit.php?id=<?= $id ?>" class="btn btn-outline-primary"><i class="bi bi-pencil me-1"></i>Edit</a>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">Actions</button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#"><i class="bi bi-whatsapp me-2 text-success"></i>Send WhatsApp</a></li>
                        <li><a class="dropdown-item" href="#"><i class="bi bi-envelope me-2 text-primary"></i>Send Email</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#"><i class="bi bi-file-pdf me-2 text-danger"></i>Export PDF</a></li>
                        <li><a class="dropdown-item text-danger" href="delete.php?id=<?= $id ?>" onclick="return confirm('Archive this lead?')"><i class="bi bi-trash me-2"></i>Delete Lead</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Stats Bar -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="stat-card primary">
                <div class="stat-info">
                    <div class="stat-label">Status</div>
                    <div class="stat-value fs-5"><?= statusBadge($lead['lead_status']) ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card success">
                <div class="stat-info">
                    <div class="stat-label">Priority</div>
                    <div class="stat-value fs-5"><?= statusBadge($lead['lead_priority']) ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card warning">
                <div class="stat-info">
                    <div class="stat-label">Next Follow-up</div>
                    <div class="stat-value fs-5 text-warning"><?= formatDate($lead['actual_followup_date']) ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card info">
                <div class="stat-info">
                    <div class="stat-label">Budget</div>
                    <div class="stat-value fs-5"><?= formatCurrency($lead['estimated_budget']) ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Main Details (Left) -->
        <div class="col-lg-8">
            <div class="crm-card mb-4">
                <div class="crm-card-header">
                    <h5 class="crm-card-title">Lead Information</h5>
                </div>
                <div class="crm-card-body">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="text-muted small text-uppercase">Project Info</label>
                            <div class="mb-3">
                                <label class="text-muted small text-uppercase">Project Timeline</label>
                                <div class="fw-semibold">Type: <span class="fw-normal"><?= e($lead['project_type'] ?: '—') ?></span></div>
                                <div class="fw-semibold text-primary">Start: <span class="fw-normal text-dark"><?= formatDate($lead['expected_closing_date']) ?></span></div>
                                <div class="fw-semibold text-info">Target End: <span class="fw-normal text-dark"><?= formatDate($lead['next_followup_date']) ?></span></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="text-muted small text-uppercase">Company Details</label>
                                <div class="fw-semibold">Industry: <span class="fw-normal"><?= e($lead['industry_type'] ?: '—') ?></span></div>
                                <div class="fw-semibold">GST: <span class="fw-normal"><?= e($lead['gst_number'] ?: '—') ?></span></div>
                            </div>
                            <div class="mb-3">
                                <label class="text-muted small text-uppercase">Address</label>
                                <div class="text-muted small">
                                    <?= e($lead['address_line1']) ?><br>
                                    <?= e($lead['address_line2']) ?><br>
                                    <?= e($lead['area']) ?>, <?= e($lead['city']) ?>, <?= e($lead['state']) ?> - <?= e($lead['pincode']) ?>
                                </div>
                                <?php if($lead['google_address']): ?>
                                    <div class="mt-2 p-2 bg-light rounded border">
                                        <div class="small fw-bold text-primary"><i class="bi bi-geo-alt-fill me-1"></i>Verified Address</div>
                                        <div class="small"><?= e($lead['google_address']) ?></div>
                                        <?php if($lead['google_maps_link']): ?>
                                            <a href="<?= e($lead['google_maps_link']) ?>" target="_blank" class="btn btn-sm btn-link p-0 mt-1 small">View on Google Maps <i class="bi bi-box-arrow-up-right ms-1"></i></a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="crm-card mb-4">
                <div class="crm-card-header d-flex justify-content-between align-items-center">
                    <h5 class="crm-card-title">Contact Persons</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addContactModal">Add New</button>
                </div>
                <div class="crm-card-body p-0">
                    <div class="table-responsive">
                        <table class="table crm-table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Name / Designation</th>
                                    <th>Contact Info</th>
                                    <th>WhatsApp</th>
                                    <th>Card</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($contacts as $c): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold"><?= e($c['name']) ?></div>
                                        <div class="text-muted small"><?= e($c['designation'] ?: '—') ?></div>
                                    </td>
                                    <td>
                                        <div class="small"><i class="bi bi-telephone me-1"></i><?= e($c['mobile'] ?: '—') ?></div>
                                        <div class="small text-muted"><i class="bi bi-envelope me-1"></i><?= e($c['email'] ?: '—') ?></div>
                                    </td>
                                    <td>
                                        <?php if($c['whatsapp']): ?>
                                            <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $c['whatsapp']) ?>" target="_blank" class="btn btn-sm btn-outline-success border-0"><i class="bi bi-whatsapp"></i> Chat</a>
                                        <?php else: ?>—<?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($c['visiting_card']): ?>
                                            <a href="<?= BASE_URL ?>/<?= e($c['visiting_card']) ?>" target="_blank" class="btn btn-sm btn-outline-info border-0"><i class="bi bi-card-image fs-5"></i> View</a>
                                        <?php else: ?>—<?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= $c['is_primary']?'bg-primary':'bg-secondary' ?>"><?= e($c['contact_type']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="crm-card mb-4">
                <div class="crm-card-header">
                    <h5 class="crm-card-title">Interested Products & Requirements</h5>
                </div>
                <div class="crm-card-body">
                    <div class="mb-3 d-flex flex-wrap gap-2">
                        <?php if(empty($products)): ?>
                            <span class="text-muted small">No products selected</span>
                        <?php else: foreach($products as $p): ?>
                            <span class="badge bg-light text-dark border"><i class="bi bi-tag-fill me-1 text-primary"></i><?= e($p) ?></span>
                        <?php endforeach; endif; ?>
                    </div>
                    <div class="p-3 bg-light rounded border border-dashed">
                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Requirement Notes</label>
                        <p class="mb-0"><?= nl2br(e($lead['requirement_description'] ?: 'No detailed requirements provided.')) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar Details (Right) -->
        <div class="col-lg-4">
            <!-- Lead Meet -->
            <div class="crm-card mb-4">
                <div class="crm-card-header d-flex justify-content-between align-items-center">
                    <h5 class="crm-card-title">Lead Meet</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addMeetingModal">Add New</button>
                </div>
                <div class="crm-card-body p-0">
                    <?php if(empty($meetings)): ?>
                        <div class="text-center text-muted py-4 small">No meetings scheduled</div>
                    <?php else: foreach($meetings as $m): ?>
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between mb-1">
                                <div class="fw-bold small"><?= e($m['type']) ?></div>
                                <?= statusBadge($m['status']) ?>
                            </div>
                            <div class="small text-muted mb-2"><?= e($m['purpose']) ?></div>
                            <div class="d-flex align-items-center gap-2">
                                <div class="avatar-xs bg-light rounded-circle d-flex align-items-center justify-content-center" style="width:20px;height:20px;font-size:9px">
                                    <?= strtoupper(substr($m['meeting_with']??'U', 0,1)) ?>
                                </div>
                                <span class="x-small fw-medium"><?= e($m['meeting_with'] ?: 'Not specified') ?></span>
                                <span class="ms-auto x-small text-muted"><?= formatDate($m['created_at']) ?></span>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>

            <!-- Timeline -->
            <div class="crm-card mb-4">
                <div class="crm-card-header">
                    <h5 class="crm-card-title">Activity Timeline</h5>
                </div>
                <div class="crm-card-body">
                    <div class="timeline">
                        <?php if(empty($timeline)): ?>
                            <div class="text-center text-muted py-4">No activities yet</div>
                        <?php else: foreach($timeline as $t): ?>
                        <li class="timeline-item">
                            <div class="timeline-dot"></div>
                            <div class="timeline-content">
                                <div class="fw-semibold"><?= e($t['action_type']) ?></div>
                                <div class="small"><?= e($t['description']) ?></div>
                                <div class="timeline-time"><?= formatDateTime($t['created_at']) ?> • <?= e($t['user_name']) ?></div>
                            </div>
                        </li>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

            <!-- Documents -->
            <div class="crm-card mb-4">
                <div class="crm-card-header">
                    <h5 class="crm-card-title">Documents & Media</h5>
                </div>
                <div class="crm-card-body">
                    <div class="row g-2">
                        <?php if(empty($documents)): ?>
                            <div class="col-12 text-center text-muted py-3">No documents uploaded</div>
                        <?php else: foreach($documents as $doc): 
                            $isImg = in_array(strtolower(pathinfo($doc['file_name'], PATHINFO_EXTENSION)), ALLOWED_IMAGES);
                        ?>
                            <div class="col-6">
                                <div class="document-item border rounded p-2 text-center position-relative h-100">
                                    <?php if($isImg): ?>
                                        <img src="<?= BASE_URL ?>/<?= e($doc['file_path']) ?>" class="img-fluid rounded mb-1" style="height: 60px; width: 100%; object-fit: cover;">
                                    <?php else: ?>
                                        <i class="bi bi-file-earmark-text fs-1 text-muted d-block mb-1"></i>
                                    <?php endif; ?>
                                    <div class="text-truncate small"><?= e($doc['file_name']) ?></div>
                                    <a href="<?= BASE_URL ?>/<?= e($doc['file_path']) ?>" target="_blank" class="stretched-link"></a>
                                </div>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<!-- Add Contact Modal -->
<div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="addContactModalLabel" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 480px;">
        <div class="modal-content border-0 shadow-xl rounded-4 overflow-hidden">

            <!-- Header -->
            <div class="modal-header border-0 px-4 py-3" style="background: linear-gradient(135deg, #3b5bdb 0%, #4c6ef5 100%);">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center" style="width:34px;height:34px;">
                        <i class="bi bi-person-plus-fill text-white" style="font-size:15px;"></i>
                    </div>
                    <div>
                        <h6 class="modal-title fw-bold text-white mb-0" id="addContactModalLabel">Add New Contact</h6>
                        <div class="text-white text-opacity-75" style="font-size:11px;">Fill in the contact details below</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="add-contact-form" action="add_contact_ajax.php" method="POST" enctype="multipart/form-data" autocomplete="off">
                <input type="hidden" name="lead_id" value="<?= $id ?>">

                <div class="modal-body px-4 py-3">

                    <!-- Name -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">FULL NAME <span class="text-danger">*</span></label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-person"></i></span>
                            <input type="text" name="name" class="form-control border-start-0 ps-1" required placeholder="Contact person's full name" style="font-size:13px;">
                        </div>
                    </div>

                    <!-- Designation + Type -->
                    <div class="row g-2 mb-3">
                        <div class="col-7">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">DESIGNATION</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-briefcase"></i></span>
                                <input type="text" name="designation" class="form-control border-start-0 ps-1" placeholder="e.g. Owner, Manager" style="font-size:13px;">
                            </div>
                        </div>
                        <div class="col-5">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">TYPE</label>
                            <select name="contact_type" class="form-select form-select-sm" style="font-size:13px;">
                                <option value="Owner">Owner</option>
                                <option value="Manager">Manager</option>
                                <option value="Architect">Architect</option>
                                <option value="Contractor">Contractor</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>

                    <!-- Mobile + WhatsApp -->
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">MOBILE <span class="text-danger">*</span></label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-telephone"></i></span>
                                <input type="tel" name="mobile" class="form-control border-start-0 ps-1" required placeholder="Mobile no." style="font-size:13px;">
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">WHATSAPP</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-success" style="font-size:13px;"><i class="bi bi-whatsapp"></i></span>
                                <input type="tel" name="whatsapp" class="form-control border-start-0 ps-1" placeholder="WhatsApp no." style="font-size:13px;">
                            </div>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">EMAIL</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-envelope"></i></span>
                            <input type="email" name="email" class="form-control border-start-0 ps-1" placeholder="Email address (optional)" style="font-size:13px;">
                        </div>
                    </div>

                    <!-- Visiting Card Upload -->
                    <div class="p-2 rounded-3 border d-flex align-items-center gap-3" style="background:#f8f9ff;">
                        <div id="card-preview-box-modal" class="rounded-2 overflow-hidden border flex-shrink-0" style="width:56px;height:40px;background:#e9ecef;display:flex;align-items:center;justify-content:center;">
                            <img id="card-preview-img-modal" src="#" class="d-none w-100 h-100" style="object-fit:cover;">
                            <i class="bi bi-card-image text-muted" id="card-placeholder-icon" style="font-size:18px;"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-semibold text-dark" style="font-size:12px;">Visiting Card</div>
                            <div class="text-muted" style="font-size:11px;">Capture or upload (optional)</div>
                        </div>
                        <label for="visiting_card_modal" class="btn btn-sm btn-outline-primary mb-0 flex-shrink-0" style="font-size:12px;">
                            <i class="bi bi-camera me-1"></i>Upload
                        </label>
                        <input type="file" id="visiting_card_modal" name="visiting_card" class="d-none" accept="image/*" capture="environment"
                            onchange="previewContactCard(this)">
                    </div>

                </div>

                <!-- Footer -->
                <div class="modal-footer border-0 px-4 pt-0 pb-3 gap-2">
                    <button type="button" class="btn btn-sm btn-light text-muted px-3" data-bs-dismiss="modal">
                        <i class="bi bi-x me-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-sm btn-primary px-4 fw-semibold shadow-sm flex-grow-1">
                        <i class="bi bi-check2-circle me-1"></i>Save Contact
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Meeting Modal -->
<div class="modal fade" id="addMeetingModal" tabindex="-1" aria-labelledby="addMeetingModalLabel" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 460px;">
        <div class="modal-content border-0 shadow-xl rounded-4 overflow-hidden">

            <!-- Header -->
            <div class="modal-header border-0 px-4 py-3" style="background: linear-gradient(135deg, #0f7173 0%, #0ca678 100%);">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center" style="width:34px;height:34px;">
                        <i class="bi bi-calendar-check-fill text-white" style="font-size:15px;"></i>
                    </div>
                    <div>
                        <h6 class="modal-title fw-bold text-white mb-0" id="addMeetingModalLabel">Record Meeting</h6>
                        <div class="text-white text-opacity-75" style="font-size:11px;">Log an interaction or follow-up</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="add-meeting-form" action="add_meeting_ajax.php" method="POST">
                <input type="hidden" name="lead_id" value="<?= $id ?>">

                <div class="modal-body px-4 py-3">

                    <!-- With Person + Type -->
                    <div class="row g-2 mb-3">
                        <div class="col-7">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">WITH PERSON</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-person-badge"></i></span>
                                <select name="meeting_with_name" class="form-select border-start-0" style="font-size:13px;">
                                    <option value="">Select contact</option>
                                    <?php
                                    $lead_contacts = db()->prepare("SELECT name FROM lead_contacts WHERE lead_id = ?");
                                    $lead_contacts->execute([$id]);
                                    foreach($lead_contacts->fetchAll() as $lc): ?>
                                        <option value="<?= e($lc['name']) ?>"><?= e($lc['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-5">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">MEETING TYPE</label>
                            <select name="meeting_type" class="form-select form-select-sm" style="font-size:13px;">
                                <?php foreach(['Site Visit', 'Office Meeting', 'Telephonic', 'Virtual Meeting'] as $mt): ?>
                                    <option value="<?= $mt ?>"><?= $mt ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Purpose -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">PURPOSE / SUMMARY <span class="text-danger">*</span></label>
                        <textarea name="meeting_purpose" class="form-control form-control-sm" rows="2" required
                            placeholder="What was discussed or decided?" style="font-size:13px;resize:none;"></textarea>
                    </div>

                    <!-- Status + Follow-up side by side with color coding -->
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">LEAD STATUS</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-bar-chart-steps"></i></span>
                                <select name="meeting_lead_status" class="form-select border-start-0" style="font-size:13px;">
                                    <?php foreach(['New', 'In Progress', 'Quoted', 'Negotiation', 'Won', 'Lost', 'On Hold'] as $st): ?>
                                        <option value="<?= $st ?>" <?= $lead['lead_status']==$st?'selected':'' ?>><?= $st ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark mb-1" style="font-size:12px;letter-spacing:.3px;">NEXT FOLLOW-UP</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light border-end-0 text-warning"><i class="bi bi-calendar2-check"></i></span>
                                <input type="date" name="actual_followup_date" class="form-control border-start-0"
                                    value="<?= date('Y-m-d', strtotime('+7 days')) ?>" style="font-size:13px;">
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Footer -->
                <div class="modal-footer border-0 px-4 pt-0 pb-3 gap-2">
                    <button type="button" class="btn btn-sm btn-light text-muted px-3" data-bs-dismiss="modal">
                        <i class="bi bi-x me-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-sm fw-semibold px-4 shadow-sm flex-grow-1 text-white"
                        style="background:linear-gradient(135deg,#0f7173,#0ca678);">
                        <i class="bi bi-calendar-plus me-1"></i>Save Meeting
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraScripts = '<script src="' . BASE_URL . '/assets/js/leads.js"></script>
<script>
function previewContactCard(input) {
    const img = document.getElementById("card-preview-img-modal");
    const icon = document.getElementById("card-placeholder-icon");
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            img.src = e.target.result;
            img.classList.remove("d-none");
            if (icon) icon.classList.add("d-none");
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>';
include __DIR__ . '/../../includes/footer.php';
?>

