<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

try {
    db()->beginTransaction();

    $createdBy = $_SESSION['user_id'];
    $leadCode = generateLeadCode();

    // 1. Insert Main Lead
    $sqlLead = "INSERT INTO leads (
        lead_code, lead_date, site_stage, project_type, lead_type, lead_source, lead_priority, lead_status,
        expected_closing_date, next_followup_date, assigned_to,
        company_name, company_type, industry_type, business_category, company_email, company_website, gst_number,
        address_line1, address_line2, area, city, state, pincode, approx_area_sqft, lat, lng, google_location,
        google_address, google_maps_link,
        product_type, requirement_description, estimated_budget, purchase_timeline, competitor_info,
        created_by, actual_followup_date
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmtLead = db()->prepare($sqlLead);
    $stmtLead->execute([
        $leadCode,
        $_POST['lead_date'] ?: date('Y-m-d'),
        $_POST['site_stage'] ?: null,
        $_POST['project_type'] ?: null,
        $_POST['lead_type'] ?: null,
        $_POST['lead_source'] ?: null,
        $_POST['lead_priority'] ?: null,
        $_POST['meeting_lead_status'] ?: ($_POST['lead_status'] ?: 'New'),
        $_POST['expected_closing_date'] ?: null,
        $_POST['next_followup_date'] ?: null,
        $_POST['assigned_to'] ?: null,
        $_POST['company_name'] ?: null,
        $_POST['company_type'] ?: null,
        $_POST['industry_type'] ?: null,
        $_POST['business_category'] ?: null,
        $_POST['company_email'] ?: null,
        $_POST['company_website'] ?: null,
        $_POST['gst_number'] ?: null,
        $_POST['address_line1'] ?: null,
        $_POST['address_line2'] ?: null,
        $_POST['area'] ?: null,
        $_POST['city'] ?: null,
        $_POST['state'] ?: null,
        $_POST['pincode'] ?: null,
        $_POST['approx_area_sqft'] ?: 0,
        $_POST['lat'] ?: null,
        $_POST['lng'] ?: null,
        $_POST['google_location'] ?: null,
        $_POST['google_address'] ?: null,
        $_POST['google_maps_link'] ?: null,
        $_POST['product_type'] ?: null,
        $_POST['requirement_description'] ?: null,
        $_POST['estimated_budget'] ?: 0,
        $_POST['purchase_timeline'] ?: null,
        $_POST['competitor_info'] ?: null,
        $createdBy,
        $_POST['actual_followup_date'] ?: null
    ]);

    $leadId = db()->lastInsertId();

    // 2. Insert Contacts
    if (!empty($_POST['contacts'])) {
        $sqlContact = "INSERT INTO lead_contacts (lead_id, contact_type, name, designation, mobile, alt_mobile, whatsapp, email, visiting_card, is_primary) VALUES (?,?,?,?,?,?,?,?,?,?)";
        $stmtContact = db()->prepare($sqlContact);
        foreach ($_POST['contacts'] as $index => $c) {
            if (empty($c['name'])) continue;
            
            $cardPath = null;
            if (!empty($_FILES['contacts']['name'][$index]['card_file'])) {
                $fileData = [
                    'name' => $_FILES['contacts']['name'][$index]['card_file'],
                    'type' => $_FILES['contacts']['type'][$index]['card_file'],
                    'tmp_name' => $_FILES['contacts']['tmp_name'][$index]['card_file'],
                    'error' => $_FILES['contacts']['error'][$index]['card_file'],
                    'size' => $_FILES['contacts']['size'][$index]['card_file']
                ];
                $cardPath = uploadFile($fileData, 'leads/cards');
            }

            $stmtContact->execute([
                $leadId,
                $c['type'] ?: 'Primary',
                $c['name'],
                $c['designation'] ?: null,
                $c['mobile'] ?: null,
                $c['alt_mobile'] ?: null,
                $c['whatsapp'] ?: null,
                $c['email'] ?: null,
                $cardPath,
                isset($c['is_primary']) ? 1 : 0
            ]);
        }
    }

    // 3. Insert Interested Products
    if (!empty($_POST['interested_products'])) {
        $sqlProd = "INSERT INTO lead_interested_products (lead_id, product_name) VALUES (?,?)";
        $stmtProd = db()->prepare($sqlProd);
        foreach ($_POST['interested_products'] as $p) {
            $stmtProd->execute([$leadId, $p]);
        }
    }

    // 4. Handle File Uploads (Standard and Camera)
    $allFiles = [];
    if (!empty($_FILES['documents']['name'][0])) {
        foreach($_FILES['documents']['name'] as $k => $name) {
            $allFiles[] = [
                'name' => $_FILES['documents']['name'][$k],
                'type' => $_FILES['documents']['type'][$k],
                'tmp_name' => $_FILES['documents']['tmp_name'][$k],
                'error' => $_FILES['documents']['error'][$k],
                'size' => $_FILES['documents']['size'][$k],
                'source' => 'Device'
            ];
        }
    }
    if (!empty($_FILES['camera_photos']['name'][0])) {
        foreach($_FILES['camera_photos']['name'] as $k => $name) {
            $allFiles[] = [
                'name' => $_FILES['camera_photos']['name'][$k],
                'type' => $_FILES['camera_photos']['type'][$k],
                'tmp_name' => $_FILES['camera_photos']['tmp_name'][$k],
                'error' => $_FILES['camera_photos']['error'][$k],
                'size' => $_FILES['camera_photos']['size'][$k],
                'source' => 'Mobile'
            ];
        }
    }

    foreach ($allFiles as $fileData) {
        $path = uploadFile($fileData, 'leads');
        if ($path) {
            $sqlDoc = "INSERT INTO lead_documents (lead_id, file_path, file_name, file_type, category, remark, uploaded_from) VALUES (?,?,?,?,?,?,?)";
            db()->prepare($sqlDoc)->execute([
                $leadId, $path, $fileData['name'], $fileData['type'], 'Site Media', $_POST['upload_remark'] ?: null, $fileData['source']
            ]);
        }
    }

    // 5. Lead Meet
    if (!empty($_POST['meeting_with_name'])) {
        $sqlMeeting = "INSERT INTO lead_meetings (lead_id, meeting_with, type, purpose, status, created_by) VALUES (?,?,?,?,?,?)";
        db()->prepare($sqlMeeting)->execute([
            $leadId, $_POST['meeting_with_name'], $_POST['meeting_type'] ?: 'Initial Visit', $_POST['meeting_purpose'] ?: 'Requirement Gathering', 'Scheduled', $createdBy
        ]);
    }

    // 6. Log Activity
    $sqlLog = "INSERT INTO lead_timeline (lead_id, user_id, action_type, description) VALUES (?,?,?,?)";
    db()->prepare($sqlLog)->execute([$leadId, $createdBy, 'Created', "Lead created with ID: $leadCode"]);

    db()->commit();
    
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(['status' => 'success', 'message' => 'Lead saved successfully', 'lead_id' => $leadId]);
        exit;
    }

    setFlash('success', 'Lead created successfully.');
    header("Location: view.php?id=$leadId");

} catch (Exception $e) {
    if (db()->inTransaction()) db()->rollBack();
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        http_response_code(200);
        echo json_encode(['status' => 'error', 'message' => 'Failed to save lead: ' . $e->getMessage()]);
        exit;
    }
    setFlash('danger', "Failed to save lead: " . $e->getMessage());
    header("Location: create.php");
}
exit;
