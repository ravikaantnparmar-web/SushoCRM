<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/constants.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM leads WHERE id = ? AND deleted_at IS NULL");
$stmt->execute([$id]);
$lead = $stmt->fetch();

if (!$lead) {
    setFlash('danger', 'Lead not found.');
    header("Location: index.php");
    exit;
}

// Fetch related
$contacts = db()->prepare("SELECT * FROM lead_contacts WHERE lead_id = ?");
$contacts->execute([$id]);
$contacts = $contacts->fetchAll();

$selectedProducts = db()->prepare("SELECT product_name FROM lead_interested_products WHERE lead_id = ?");
$selectedProducts->execute([$id]);
$selectedProducts = $selectedProducts->fetchAll(PDO::FETCH_COLUMN);

$users = getAllUsers();
$pageTitle = 'Edit Lead: ' . e($lead['lead_code']);

include __DIR__ . '/../../includes/header.php'; ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>

<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Edit Lead</div>
</div>

<div class="page-content">
    <?= flashHtml() ?>
    <div class="page-header">
        <div class="page-header-left">
            <h1>Edit Lead: <?= e($lead['lead_code']) ?></h1>
        </div>
        <div class="page-header-right">
            <a href="view.php?id=<?= $id ?>" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" form="lead-form" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i>Update Lead</button>
        </div>
    </div>

    <form id="lead-form" action="update.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $id ?>">
        <div class="row">
            <div class="col-lg-8">
                <!-- LEAD MASTER INFORMATION -->
                <div class="crm-form-section">
                    <div class="form-section-title"><i class="bi bi-info-circle me-2"></i>LEAD MASTER INFORMATION</div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Lead ID</label>
                            <input type="text" class="form-control bg-light" value="<?= e($lead['lead_code']) ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lead Date</label>
                            <input type="date" class="form-control" name="lead_date" value="<?= $lead['lead_date'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lead Status</label>
                            <select name="lead_status" class="form-select" required>
                                <?php foreach($leadStatuses as $st): ?>
                                    <option value="<?= $st ?>" <?= $lead['lead_status']==$st?'selected':'' ?>><?= $st ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <!-- ... (Other fields similar to create.php) ... -->
                        <div class="col-md-4">
                            <label class="form-label">Site Stage</label>
                            <select name="site_stage" class="form-select">
                                <?php foreach($siteStages as $stage): ?>
                                    <option value="<?= $stage ?>" <?= $lead['site_stage']==$stage?'selected':'' ?>><?= $stage ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Project Type</label>
                            <select name="project_type" class="form-select">
                                <?php foreach($projectTypes as $type): ?>
                                    <option value="<?= $type ?>" <?= $lead['project_type']==$type?'selected':'' ?>><?= $type ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lead Type</label>
                            <select name="lead_type" class="form-select">
                                <?php foreach($leadTypes as $type): ?>
                                    <option value="<?= $type ?>" <?= $lead['lead_type']==$type?'selected':'' ?>><?= $type ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lead Source</label>
                            <select name="lead_source" class="form-select">
                                <?php foreach($leadSources as $source): ?>
                                    <option value="<?= $source ?>" <?= $lead['lead_source']==$source?'selected':'' ?>><?= $source ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Lead Priority</label>
                            <select name="lead_priority" class="form-select">
                                <?php foreach($leadPriorities as $prio): ?>
                                    <option value="<?= $prio ?>" <?= $lead['lead_priority']==$prio?'selected':'' ?>><?= $prio ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Assign To</label>
                            <select name="assigned_to" class="form-select">
                                <option value="">Select Employee</option>
                                <?php foreach($users as $u): ?>
                                    <option value="<?= $u['id'] ?>" <?= $lead['assigned_to']==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-primary fw-bold">Project Start Date</label>
                            <input type="date" class="form-control border-primary" name="expected_closing_date" value="<?= $lead['expected_closing_date'] ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-info fw-bold">Expected Project Closing Date</label>
                            <input type="date" class="form-control border-info" name="next_followup_date" value="<?= $lead['next_followup_date'] ?>">
                        </div>
                    </div>
                </div>

                <!-- COMPANY INFORMATION -->
                <div class="crm-form-section">
                    <div class="form-section-title collapsible d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-building me-2"></i>COMPANY INFORMATION</span>
                        <i class="bi bi-chevron-up"></i>
                    </div>
                    <div class="section-content">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Company Name</label>
                                <input type="text" name="company_name" class="form-control" value="<?= e($lead['company_name']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Company Type</label>
                                <select name="company_type" class="form-select">
                                    <?php foreach($companyTypes as $ct): ?>
                                        <option value="<?= $ct ?>" <?= $lead['company_type']==$ct?'selected':'' ?>><?= $ct ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Industry Type</label>
                                <select name="industry_type" class="form-select">
                                    <?php foreach($industryTypes as $it): ?>
                                        <option value="<?= $it ?>" <?= $lead['industry_type']==$it?'selected':'' ?>><?= $it ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Business Category</label>
                                <select name="business_category" class="form-select">
                                    <?php foreach($businessCategories as $bc): ?>
                                        <option value="<?= $bc ?>" <?= $lead['business_category']==$bc?'selected':'' ?>><?= $bc ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">GST Number</label>
                                <input type="text" name="gst_number" class="form-control" value="<?= e($lead['gst_number']) ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Company Status</label>
                                <select name="company_status" class="form-select">
                                    <option value="Active" <?= $lead['company_status']=='Active'?'selected':'' ?>>Active</option>
                                    <option value="Inactive" <?= $lead['company_status']=='Inactive'?'selected':'' ?>>Inactive</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="company_email" class="form-control" value="<?= e($lead['company_email']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Website</label>
                                <input type="url" name="company_website" class="form-control" value="<?= e($lead['company_website']) ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ADDRESS INFORMATION -->
                <div class="crm-form-section">
                    <div class="form-section-title collapsible d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-geo-alt me-2"></i>ADDRESS INFORMATION</span>
                        <i class="bi bi-chevron-up"></i>
                    </div>
                    <div class="section-content">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Address Line 1</label>
                                <input type="text" name="address_line1" class="form-control" value="<?= e($lead['address_line1']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Address Line 2</label>
                                <input type="text" name="address_line2" class="form-control" value="<?= e($lead['address_line2']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Area</label>
                                <input type="text" name="area" class="form-control" value="<?= e($lead['area']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-control" value="<?= e($lead['city']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">State</label>
                                <input type="text" name="state" class="form-control" value="<?= e($lead['state']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Pincode</label>
                                <input type="text" name="pincode" class="form-control" value="<?= e($lead['pincode']) ?>">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label d-flex justify-content-between">
                                    <span>Google Map Location & Address</span>
                                    <button type="button" class="btn btn-link btn-sm p-0" id="fetch-location-btn"><i class="bi bi-geo-alt-fill me-1"></i>Fetch GPS & Address</button>
                                </label>
                                <div class="row g-2">
                                    <div class="col-md-4">
                                        <input type="text" name="google_location" id="google_location" class="form-control" readonly value="<?= e($lead['google_location']) ?>" placeholder="Lat, Lng">
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" name="google_address" id="google_address" class="form-control" value="<?= e($lead['google_address']) ?>" placeholder="Fetched Address">
                                    </div>
                                    <div class="col-md-12">
                                        <input type="text" name="google_maps_link" id="google_maps_link" class="form-control" value="<?= e($lead['google_maps_link']) ?>" placeholder="Google Maps Link">
                                    </div>
                                </div>
                                <input type="hidden" name="lat" id="lat" value="<?= $lead['lat'] ?>">
                                <input type="hidden" name="lng" id="lng" value="<?= $lead['lng'] ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- CONTACT PERSON MANAGEMENT -->
                <div class="crm-form-section">
                    <div class="form-section-title d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-person-lines-fill me-2"></i>CONTACT PERSON MANAGEMENT</span>
                        <div class="d-flex gap-2">
                            <button type="button" id="add-contact-btn" class="btn btn-sm btn-outline-primary"><i class="bi bi-plus-lg me-1"></i>Add Contact</button>
                            <button type="button" class="btn btn-sm btn-success" id="inline-save-btn"><i class="bi bi-check-circle me-1"></i>Save Lead</button>
                        </div>
                    </div>
                    <div id="contacts-container">
                        <?php foreach($contacts as $i => $c): ?>
                        <div class="contact-item border rounded p-3 mb-3 position-relative bg-light bg-opacity-50">
                            <?php if($i > 0): ?><button type="button" class="btn-close position-absolute top-0 end-0 m-2 remove-contact"></button><?php endif; ?>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="contacts[<?= $i ?>][name]" class="form-control" value="<?= e($c['name']) ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <label class="form-label mb-0">Designation</label>
                                        <span class="x-small text-muted"><i class="bi bi-keyboard"></i> F2 to Add</span>
                                    </div>
                                    <select name="contacts[<?= $i ?>][type]" class="form-select designation-select">
                                        <?php foreach($designations as $d): ?>
                                            <option value="<?= $d ?>" <?= $c['contact_type']==$d?'selected':'' ?>><?= $d ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="contacts[<?= $i ?>][email]" class="form-control" value="<?= e($c['email']) ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Mobile</label>
                                    <input type="text" name="contacts[<?= $i ?>][mobile]" class="form-control" value="<?= e($c['mobile']) ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">WhatsApp</label>
                                    <input type="text" name="contacts[<?= $i ?>][whatsapp]" class="form-control" value="<?= e($c['whatsapp']) ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Alt. Mobile</label>
                                    <input type="text" name="contacts[<?= $i ?>][alt_mobile]" class="form-control" value="<?= e($c['alt_mobile']) ?>">
                                </div>
                                <div class="col-12 mt-2">
                                    <div class="d-flex align-items-center justify-content-between p-2 bg-white border rounded">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="card-preview-box border rounded d-flex align-items-center justify-content-center bg-light" id="card-preview-<?= $i ?>" style="width:100px; height:60px; overflow:hidden;">
                                                <?php if($c['visiting_card']): ?>
                                                    <img src="<?= BASE_URL ?>/<?= e($c['visiting_card']) ?>" style="width:100%; height:100%; object-fit: cover;">
                                                <?php else: ?>
                                                    <i class="bi bi-card-image text-muted fs-4"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold small">Visiting Card</div>
                                                <div class="text-muted x-small"><?= $c['visiting_card'] ? 'Update or capture new card' : 'Capture or upload card image' ?></div>
                                            </div>
                                        </div>
                                        <div class="d-flex gap-2">
                                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="document.getElementById('card-input-<?= $i ?>').click()">
                                                <i class="bi bi-camera-fill me-1"></i><?= $c['visiting_card'] ? 'Change' : 'Capture' ?>
                                            </button>
                                            <input type="file" name="contacts[<?= $i ?>][card_file]" id="card-input-<?= $i ?>" class="d-none card-input" accept="image/*" capture="environment" data-preview="#card-preview-<?= $i ?>">
                                            <input type="hidden" name="contacts[<?= $i ?>][existing_card]" value="<?= e($c['visiting_card']) ?>">
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="contacts[<?= $i ?>][is_primary]" value="<?= $c['is_primary'] ?>">
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- PRODUCT SECTION -->
                <div class="crm-form-section">
                    <div class="form-section-title">PRODUCT / REQUIREMENT</div>
                    <div class="mb-3">
                        <label class="form-label">Interested Products</label>
                        <div class="border rounded p-2" style="max-height: 200px; overflow-y: auto;">
                            <?php foreach($interestedProducts as $ip): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="interested_products[]" value="<?= $ip ?>" id="p_<?= md5($ip) ?>" <?= in_array($ip, $selectedProducts)?'checked':'' ?>>
                                    <label class="form-check-label" for="p_<?= md5($ip) ?>"><?= $ip ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estimated Budget</label>
                        <input type="number" name="estimated_budget" class="form-control" step="0.01" value="<?= $lead['estimated_budget'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Requirement Description</label>
                        <textarea name="requirement_description" class="form-control" rows="4"><?= e($lead['requirement_description']) ?></textarea>
                    </div>
                </div>

                <!-- LEAD MEET -->
                <div class="crm-form-section">
                    <div class="form-section-title"><i class="bi bi-calendar-event me-2"></i>LEAD MEET</div>
                    <div class="mb-3">
                        <label class="form-label">Meeting With Personnel</label>
                        <select name="meeting_with_name" id="meeting-with-contact" class="form-select">
                            <option value="">Select Contact Person</option>
                        </select>
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label small text-muted">Update Lead Status</label>
                            <select name="meeting_lead_status" class="form-select form-select-sm">
                                <?php foreach($leadStatuses as $st): ?>
                                    <option value="<?= $st ?>" <?= $lead['lead_status']==$st?'selected':'' ?>><?= $st ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small text-muted">Next Follow-up Date</label>
                            <input type="date" name="actual_followup_date" class="form-control form-select-sm" value="<?= $lead['actual_followup_date'] ?: date('Y-m-d', strtotime('+7 days')) ?>">
                        </div>
                    </div>
                </div>

                <!-- DOCUMENTS -->
                <div class="crm-form-section">
                    <div class="form-section-title"><i class="bi bi-file-earmark-arrow-up me-2"></i>Take Image or Upload document</div>
                    <div class="mb-3">
                        <label class="form-label d-flex justify-content-between align-items-center">
                            <span>Site Photo / Drawing</span>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="document.getElementById('cameraInput').click()"><i class="bi bi-camera-fill me-1"></i>Take Photo</button>
                        </label>
                        <input type="file" name="documents[]" id="documentInput" class="form-control" multiple>
                        <input type="file" name="camera_photos[]" id="cameraInput" class="d-none" accept="image/*" capture="environment" multiple>
                        <div id="file-preview-container" class="d-flex flex-wrap gap-2 mt-3"></div>
                        <small class="text-muted">Upload files or take photos. Previews will appear above.</small>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Upload Remark</label>
                        <input type="text" name="upload_remark" class="form-control">
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>

<!-- Add Designation Modal -->
<div class="modal fade" id="addDesignationModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
    <div class="modal-content shadow-lg border-0">
      <div class="modal-header bg-primary text-white border-0">
        <h6 class="modal-title fw-bold">Add New Designation</h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label small fw-bold">Designation Name</label>
          <input type="text" id="new-designation-input" class="form-control" placeholder="e.g. Project Lead">
        </div>
        <button type="button" id="save-designation-btn" class="btn btn-primary w-100">Add to List</button>
      </div>
    </div>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/leads.js"></script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
