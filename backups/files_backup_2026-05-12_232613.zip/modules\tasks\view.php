<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT t.*, u.name AS assignee_name, c.name AS creator_name FROM tasks t LEFT JOIN users u ON t.assigned_to = u.id LEFT JOIN users c ON t.created_by = c.id WHERE t.id=?");
$stmt->execute([$id]);
$t = $stmt->fetch();
if (!$t) { setFlash('danger','Task not found.'); header('Location: '.BASE_URL.'/modules/tasks/index.php'); exit; }

$pageTitle = 'Task: ' . $t['title'];

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">View Task</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<div class="page-header">
  <div class="page-header-left"><h1><?= e($t['title']) ?></h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/tasks/index.php">Tasks</a></li><li class="breadcrumb-item active"><?= e($t['title']) ?></li></ol></nav>
  </div>
  <div><?= statusBadge($t['status']) ?></div>
  <a href="<?= BASE_URL ?>/modules/tasks/index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="row">
  <div class="col-lg-8">
    <div class="crm-card">
      <div class="crm-card-body p-4">
        <h5 class="fw-bold mb-3 border-bottom pb-2">Task Details</h5>
        
        <div class="row mb-3">
          <div class="col-sm-3 text-muted">Title</div>
          <div class="col-sm-9 fw-semibold fs-5"><?= e($t['title']) ?></div>
        </div>
        
        <div class="row mb-3">
          <div class="col-sm-3 text-muted">Description</div>
          <div class="col-sm-9"><div class="p-3 bg-light rounded" style="white-space:pre-line"><?= e($t['description'] ?: 'No description provided.') ?></div></div>
        </div>

        <?php if($t['related_module']): ?>
        <div class="row mb-3">
          <div class="col-sm-3 text-muted">Related To</div>
          <div class="col-sm-9">
            <span class="badge bg-secondary text-uppercase"><?= e($t['related_module']) ?> #<?= $t['related_id'] ?></span>
          </div>
        </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
  
  <div class="col-lg-4">
    <div class="crm-card mb-4">
      <div class="crm-card-body p-4">
        <h5 class="fw-bold mb-3 border-bottom pb-2">Metadata</h5>
        
        <div class="mb-3">
          <span class="text-muted d-block small text-uppercase">Assigned To</span>
          <div class="fw-semibold">
            <?php if($t['assignee_name']): ?>
              <i class="bi bi-person-circle text-primary me-1"></i> <?= e($t['assignee_name']) ?>
            <?php else: ?>
              <span class="text-muted fst-italic">Unassigned</span>
            <?php endif; ?>
          </div>
        </div>
        
        <div class="mb-3">
          <span class="text-muted d-block small text-uppercase">Priority</span>
          <?php
            $pClasses = ['low'=>'bg-info','medium'=>'bg-primary','high'=>'bg-warning text-dark','urgent'=>'bg-danger'];
            $pClass = $pClasses[$t['priority']] ?? 'bg-secondary';
          ?>
          <span class="badge <?= $pClass ?>"><?= ucfirst($t['priority']) ?></span>
        </div>
        
        <div class="mb-3">
          <span class="text-muted d-block small text-uppercase">Due Date</span>
          <div class="fw-semibold <?= ($t['due_date'] && $t['due_date'] < date('Y-m-d') && $t['status'] !== 'completed') ? 'text-danger' : '' ?>">
            <?= $t['due_date'] ? formatDate($t['due_date']) : 'None' ?>
          </div>
        </div>

        <?php if($t['completed_at']): ?>
        <div class="mb-3">
          <span class="text-muted d-block small text-uppercase">Completed At</span>
          <div class="fw-semibold text-success"><i class="bi bi-check-circle-fill me-1"></i><?= formatDateTime($t['completed_at']) ?></div>
        </div>
        <?php endif; ?>
        
        <div class="mt-4 pt-3 border-top small text-muted">
          Created by <?= e($t['creator_name']) ?> on <?= formatDateTime($t['created_at']) ?>
        </div>
      </div>
    </div>
  </div>
</div>

</div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
