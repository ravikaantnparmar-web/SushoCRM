<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) { $errors[] = 'Invalid CSRF token.'; }
    $name    = sanitize($_POST['name'] ?? '');
    $company = sanitize($_POST['company'] ?? '');
    $email   = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $website = filter_var($_POST['website'] ?? '', FILTER_SANITIZE_URL);
    $phone   = sanitize($_POST['phone'] ?? '');
    $whatsapp = sanitize($_POST['whatsapp_number'] ?? '');
    $gst     = sanitize($_POST['gst_number'] ?? '');
    $pan     = sanitize($_POST['pan_number'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $city    = sanitize($_POST['city'] ?? '');
    $state   = sanitize($_POST['state'] ?? '');
    $pincode = sanitize($_POST['pincode'] ?? '');
    $notes   = sanitize($_POST['notes'] ?? '');
    $status  = in_array($_POST['status'] ?? '', ['Prospect','Active','Inactive','Lost','Blacklisted']) ? $_POST['status'] : 'Active';
    $customer_type = in_array($_POST['customer_type'] ?? '', ['Dealer', 'Distributor', 'Architect', 'Interior Designer', 'Builder', 'Contractor', 'Retail Customer', 'Corporate Client', 'Vendor/Supplier', 'Channel Partner']) ? $_POST['customer_type'] : 'Retail Customer';
    $business_category = in_array($_POST['business_category'] ?? '', ['Residential', 'Commercial', 'Hospitality', 'Retail', 'Industrial']) ? $_POST['business_category'] : 'Residential';
    $industry_type = in_array($_POST['industry_type'] ?? '', ['Construction', 'Interior Design', 'Real Estate', 'Furniture', 'Luxury Products', 'Architecture Firm']) ? $_POST['industry_type'] : 'Real Estate';
    $preferred_communication = in_array($_POST['preferred_communication'] ?? '', ['Call', 'WhatsApp', 'Email', 'Meeting']) ? $_POST['preferred_communication'] : 'Call';
    $credit  = (float)($_POST['credit_limit'] ?? 0);

    if (empty($name)) $errors[] = 'Customer name is required.';
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';

    if (empty($errors)) {
        $code = generateCustomerCode();
        db()->prepare("INSERT INTO customers (customer_code,name,company,email,website,phone,whatsapp_number,gst_number,pan_number,address,city,state,pincode,credit_limit,notes,status,customer_type,business_category,industry_type,preferred_communication,created_by)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$code,$name,$company,$email,$website,$phone,$whatsapp,$gst,$pan,$address,$city,$state,$pincode,$credit,$notes,$status,$customer_type,$business_category,$industry_type,$preferred_communication,$_SESSION['user_id']]);
        $id = db()->lastInsertId();
        logActivity('customers','create',"Created customer: $name",$id);
        setFlash('success', "Customer '$name' created successfully.");
        header('Location: ' . BASE_URL . '/modules/customers/index.php');
        exit;
    }
}
$pageTitle = 'Add Customer';
$states = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi'];
include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Add Customer</div>
</div>
<div class="page-content">
<div class="page-header">
  <div class="page-header-left">
    <h1>Add Customer</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li>
      <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/customers/index.php">Customers</a></li>
      <li class="breadcrumb-item active">Add</li>
    </ol></nav>
  </div>
  <a href="<?= BASE_URL ?>/modules/customers/index.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul></div>
<?php endif; ?>

<form method="POST" novalidate>
  <?= csrfField() ?>
  <div class="row g-4">
    <div class="col-12 col-lg-8">
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-person me-2"></i>Basic Information</div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Customer Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" value="<?= e($_POST['name']??'') ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Company Name</label>
            <input type="text" name="company" class="form-control" value="<?= e($_POST['company']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" value="<?= e($_POST['email']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Website</label>
            <input type="url" name="website" class="form-control" placeholder="https://example.com" value="<?= e($_POST['website']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Phone Number</label>
            <input type="text" name="phone" class="form-control" value="<?= e($_POST['phone']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">WhatsApp Number</label>
            <input type="text" name="whatsapp_number" class="form-control" value="<?= e($_POST['whatsapp_number']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">GST Number</label>
            <input type="text" name="gst_number" class="form-control" maxlength="20" value="<?= e($_POST['gst_number']??'') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">PAN Number</label>
            <input type="text" name="pan_number" class="form-control" maxlength="15" value="<?= e($_POST['pan_number']??'') ?>">
          </div>
        </div>
      </div>

      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-person-lines-fill me-2"></i>Profiling Information</div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Customer Type</label>
            <select name="customer_type" class="form-select">
              <?php foreach(['Dealer', 'Distributor', 'Architect', 'Interior Designer', 'Builder', 'Contractor', 'Retail Customer', 'Corporate Client', 'Vendor/Supplier', 'Channel Partner'] as $opt): ?>
                <option value="<?= $opt ?>" <?= (($_POST['customer_type']??'Retail Customer')===$opt)?'selected':'' ?>><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Business Category</label>
            <select name="business_category" class="form-select">
              <?php foreach(['Residential', 'Commercial', 'Hospitality', 'Retail', 'Industrial'] as $opt): ?>
                <option value="<?= $opt ?>" <?= (($_POST['business_category']??'Residential')===$opt)?'selected':'' ?>><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Industry Type</label>
            <select name="industry_type" class="form-select">
              <?php foreach(['Construction', 'Interior Design', 'Real Estate', 'Furniture', 'Luxury Products', 'Architecture Firm'] as $opt): ?>
                <option value="<?= $opt ?>" <?= (($_POST['industry_type']??'Real Estate')===$opt)?'selected':'' ?>><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Preferred Communication</label>
            <select name="preferred_communication" class="form-select">
              <?php foreach(['Call', 'WhatsApp', 'Email', 'Meeting'] as $opt): ?>
                <option value="<?= $opt ?>" <?= (($_POST['preferred_communication']??'Call')===$opt)?'selected':'' ?>><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>

      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-geo-alt me-2"></i>Address</div>
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Street Address</label>
            <textarea name="address" class="form-control" rows="2"><?= e($_POST['address']??'') ?></textarea>
          </div>
          <div class="col-md-4">
            <label class="form-label">City</label>
            <input type="text" name="city" class="form-control" value="<?= e($_POST['city']??'') ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">State</label>
            <select name="state" class="form-select">
              <option value="">Select State</option>
              <?php foreach($states as $s): ?>
                <option value="<?= e($s) ?>" <?= (($_POST['state']??'')===$s)?'selected':'' ?>><?= e($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Pincode</label>
            <input type="text" name="pincode" class="form-control" maxlength="10" value="<?= e($_POST['pincode']??'') ?>">
          </div>
        </div>
      </div>

      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-sticky me-2"></i>Notes</div>
        <textarea name="notes" class="form-control" rows="3" placeholder="Internal notes about this customer..."><?= e($_POST['notes']??'') ?></textarea>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-gear me-2"></i>Settings</div>
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php foreach(['Prospect', 'Active', 'Inactive', 'Lost', 'Blacklisted'] as $opt): ?>
              <option value="<?= $opt ?>" <?= (($_POST['status']??'Active')===$opt)?'selected':'' ?>><?= $opt ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Credit Limit (<?= CURRENCY_SYMBOL ?>)</label>
          <input type="number" name="credit_limit" class="form-control" min="0" step="0.01" value="<?= e($_POST['credit_limit']??'0') ?>">
        </div>
      </div>

      <div class="crm-form-section">
        <div class="d-grid gap-2">
          <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-2"></i>Save Customer</button>
          <a href="<?= BASE_URL ?>/modules/customers/index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
      </div>
    </div>
  </div>
</form>
</div>
</div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
