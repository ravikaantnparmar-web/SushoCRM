<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT q.*, c.name AS customer_name, c.company AS customer_company, c.address, c.city, c.state, c.pincode, c.email, c.phone, u.name AS created_by_name FROM quotations q JOIN customers c ON q.customer_id = c.id LEFT JOIN users u ON q.created_by = u.id WHERE q.id=?");
$stmt->execute([$id]);
$q = $stmt->fetch();
if (!$q) { setFlash('danger','Quotation not found.'); header('Location: '.BASE_URL.'/modules/quotations/index.php'); exit; }

$stmtItems = db()->prepare("SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order ASC");
$stmtItems->execute([$id]);
$items = $stmtItems->fetchAll();

$pageTitle = 'Quotation: ' . $q['quote_number'];
include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">View Quotation</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<div class="page-header d-print-none">
  <div class="page-header-left"><h1><?= e($q['quote_number']) ?></h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/quotations/index.php">Quotations</a></li><li class="breadcrumb-item active"><?= e($q['quote_number']) ?></li></ol></nav>
  </div>
  <div><?= statusBadge($q['status']) ?></div>
</div>

<div class="crm-card print-container">
  <div class="crm-card-body p-4 p-md-5">
    <!-- Header -->
    <div class="row mb-5 border-bottom pb-4">
      <div class="col-sm-6">
        <h2 class="fw-bold text-primary mb-1"><?= APP_NAME ?></h2>
        <div class="text-muted small">
          <?= COMPANY_ADDRESS ?><br>
          Email: <?= COMPANY_EMAIL ?> | Phone: <?= COMPANY_PHONE ?><br>
          GST: <?= COMPANY_GST ?>
        </div>
      </div>
      <div class="col-sm-6 text-sm-end mt-4 mt-sm-0">
        <h3 class="text-uppercase text-muted fw-bold mb-3">Quotation</h3>
        <div class="row text-start text-sm-end">
          <div class="col-6 col-sm-12"><strong class="small text-muted text-uppercase">Quote Number</strong><br><span class="fs-6"><?= e($q['quote_number']) ?></span></div>
          <div class="col-6 col-sm-12 mt-2"><strong class="small text-muted text-uppercase">Date</strong><br><span><?= formatDate($q['created_at']) ?></span></div>
          <?php if($q['valid_until']): ?>
            <div class="col-6 col-sm-12 mt-2"><strong class="small text-muted text-uppercase">Valid Until</strong><br><span><?= formatDate($q['valid_until']) ?></span></div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    
    <!-- Customer Details -->
    <div class="row mb-5">
      <div class="col-sm-6">
        <strong class="small text-muted text-uppercase mb-2 d-block">Quotation For:</strong>
        <div class="fs-6 fw-semibold text-dark"><?= e($q['customer_name']) ?></div>
        <?php if($q['customer_company']): ?><div><?= e($q['customer_company']) ?></div><?php endif; ?>
        <div class="text-muted small mt-1">
          <?= e($q['address']) ?><br>
          <?= e($q['city']) ?><?= $q['state'] ? ', ' . e($q['state']) : '' ?> <?= e($q['pincode']) ?><br>
          Phone: <?= e($q['phone'] ?: '—') ?><br>
          Email: <?= e($q['email'] ?: '—') ?>
        </div>
      </div>
    </div>

    <!-- Items Table -->
    <div class="table-responsive mb-4">
      <table class="table table-bordered border-primary mb-0" style="--bs-border-opacity: .2;">
        <thead class="table-light">
          <tr>
            <th class="py-3">#</th>
            <th class="py-3">Description</th>
            <th class="text-end py-3">Qty</th>
            <th class="text-end py-3">Price</th>
            <th class="text-end py-3">Tax</th>
            <th class="text-end py-3">Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($items as $i => $item): ?>
          <tr>
            <td class="text-muted"><?= $i+1 ?></td>
            <td><?= e($item['description']) ?></td>
            <td class="text-end"><?= (float)$item['qty'] ?> <?= e($item['unit']) ?></td>
            <td class="text-end"><?= formatCurrency($item['unit_price']) ?></td>
            <td class="text-end"><?= $item['tax_rate'] ?>%</td>
            <td class="text-end fw-semibold text-dark"><?= formatCurrency($item['line_total']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Totals -->
    <div class="row justify-content-end mb-5">
      <div class="col-sm-6 col-md-5 col-lg-4">
        <table class="table table-sm table-borderless mb-0">
          <tr><td class="text-muted">Subtotal</td><td class="text-end"><?= formatCurrency($q['subtotal']) ?></td></tr>
          <?php if($q['discount_amount'] > 0): ?>
          <tr><td class="text-muted">Discount <?= $q['discount_type']==='percent'?"({$q['discount_value']}%)":'' ?></td><td class="text-end text-danger">- <?= formatCurrency($q['discount_amount']) ?></td></tr>
          <?php endif; ?>
          <tr><td class="text-muted">Tax Amount</td><td class="text-end"><?= formatCurrency($q['tax_amount']) ?></td></tr>
          <tr class="border-top border-2"><td class="fw-bold text-dark pt-2 fs-5">Total</td><td class="text-end fw-bold text-primary pt-2 fs-5"><?= formatCurrency($q['total']) ?></td></tr>
        </table>
      </div>
    </div>

    <!-- Terms & Notes -->
    <div class="row">
      <div class="col-md-6 mb-4 mb-md-0">
        <?php if($q['terms']): ?>
        <strong class="small text-muted text-uppercase mb-2 d-block">Terms & Conditions</strong>
        <div class="small text-muted" style="white-space:pre-line"><?= e($q['terms']) ?></div>
        <?php endif; ?>
      </div>
      <div class="col-md-6">
        <?php if($q['notes']): ?>
        <strong class="small text-muted text-uppercase mb-2 d-block">Notes</strong>
        <div class="small text-muted" style="white-space:pre-line"><?= e($q['notes']) ?></div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>
</div></div></div>
<style>
@media print {
  body * { visibility: hidden; }
  .print-container, .print-container * { visibility: visible; }
  .print-container { position: absolute; left: 0; top: 0; width: 100%; border: none !important; box-shadow: none !important; }
  .main-content, .page-content { padding: 0 !important; margin: 0 !important; }
}
</style>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
