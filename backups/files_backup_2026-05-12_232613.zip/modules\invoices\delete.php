<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM invoices WHERE id=?");
$stmt->execute([$id]);
$inv = $stmt->fetch();
if (!$inv) { setFlash('danger','Invoice not found.'); header('Location: '.BASE_URL.'/modules/invoices/index.php'); exit; }

// Optionally we should reverse customer balance here
if ($inv['total'] - $inv['amount_paid'] != 0) {
    db()->prepare("UPDATE customers SET outstanding_balance = outstanding_balance - ? WHERE id=?")->execute([$inv['total'] - $inv['amount_paid'], $inv['customer_id']]);
}

db()->prepare("DELETE FROM invoices WHERE id=?")->execute([$id]);
logActivity('invoices','delete',"Deleted invoice: {$inv['invoice_number']}",$id);
setFlash('success',"Invoice '{$inv['invoice_number']}' deleted.");
header('Location: '.BASE_URL.'/modules/invoices/index.php');
exit;
