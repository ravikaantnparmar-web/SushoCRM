<?php
error_reporting(0);
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/functions.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        db()->beginTransaction();

        $leadId = $_POST['lead_id'];
        $meetingWith = $_POST['meeting_with_name'] ?: null;
        $type = $_POST['meeting_type'];
        $purpose = $_POST['meeting_purpose'];
        $status = $_POST['meeting_lead_status'];
        $followupDate = $_POST['actual_followup_date'] ?: null;
        $createdBy = $_SESSION['user_id'] ?? $_SESSION['id'] ?? null; 

        // 1. Insert Meeting Record
        $sqlMeeting = "INSERT INTO lead_meetings (lead_id, meeting_with, type, purpose, status, created_by) 
                      VALUES (?,?,?,?,?,?)";
        db()->prepare($sqlMeeting)->execute([$leadId, $meetingWith, $type, $purpose, $status, $createdBy]);

        // 2. Update Master Lead Record
        $sqlLead = "UPDATE leads SET lead_status = ?, actual_followup_date = ? WHERE id = ?";
        db()->prepare($sqlLead)->execute([$status, $followupDate, $leadId]);

        // 3. Add Timeline Entry
        $sqlTimeline = "INSERT INTO lead_timeline (lead_id, action_type, description, user_id) 
                        VALUES (?, 'Meeting', ?, ?)";
        $desc = "Recorded $type with $meetingWith. Status updated to $status.";
        db()->prepare($sqlTimeline)->execute([$leadId, $desc, $createdBy]);

        db()->commit();
        echo json_encode(['status' => 'success', 'message' => 'Meeting recorded successfully']);
    } catch (Exception $e) {
        if (db()->inTransaction()) db()->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
