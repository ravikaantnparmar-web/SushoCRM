<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

$id = (int)$_POST['id'];

try {
    db()->beginTransaction();

    $sql = "UPDATE leads SET 
        lead_date = ?, site_stage = ?, project_type = ?, lead_type = ?, lead_source = ?, lead_priority = ?, lead_status = ?,
        expected_closing_date = ?, next_followup_date = ?, assigned_to = ?,
        company_name = ?, company_type = ?, industry_type = ?, business_category = ?, company_email = ?, company_website = ?, gst_number = ?,
        address_line1 = ?, address_line2 = ?, area = ?, city = ?, state = ?, pincode = ?, approx_area_sqft = ?,
        product_type = ?, requirement_description = ?, estimated_budget = ?, purchase_timeline = ?, competitor_info = ?,
        updated_by = ?, actual_followup_date = ?
        WHERE id = ?";

    $stmt = db()->prepare($sql);
    $stmt->execute([
        $_POST['lead_date'], $_POST['site_stage'] ?: null, $_POST['project_type'] ?: null, $_POST['lead_type'] ?: null, 
        $_POST['lead_source'] ?: null, $_POST['lead_priority'] ?: null, 
        $_POST['meeting_lead_status'] ?: ($_POST['lead_status'] ?: 'New'),
        $_POST['expected_closing_date'] ?: null, $_POST['next_followup_date'] ?: null, $_POST['assigned_to'] ?: null,
        $_POST['company_name'] ?: null, $_POST['company_type'] ?: null, $_POST['industry_type'] ?: null, $_POST['business_category'] ?: null,
        $_POST['company_email'] ?: null, $_POST['company_website'] ?: null, $_POST['gst_number'] ?: null,
        $_POST['address_line1'] ?: null, $_POST['address_line2'] ?: null, $_POST['area'] ?: null, $_POST['city'] ?: null, $_POST['state'] ?: null, $_POST['pincode'] ?: null, $_POST['approx_area_sqft'] ?: 0,
        $_POST['product_type'] ?: null, $_POST['requirement_description'] ?: null, $_POST['estimated_budget'] ?: 0, $_POST['purchase_timeline'] ?: null, $_POST['competitor_info'] ?: null,
        $_SESSION['user_id'], $_POST['actual_followup_date'] ?: null, $id
    ]);

    // 2. Refresh Contacts (Delete and re-insert)
    db()->prepare("DELETE FROM lead_contacts WHERE lead_id = ?")->execute([$id]);
    if (!empty($_POST['contacts'])) {
        $stmtContact = db()->prepare("INSERT INTO lead_contacts (lead_id, contact_type, name, designation, mobile, alt_mobile, whatsapp, email, visiting_card, is_primary) VALUES (?,?,?,?,?,?,?,?,?,?)");
        foreach ($_POST['contacts'] as $index => $c) {
            if (empty($c['name'])) continue;

            $cardPath = $c['existing_card'] ?: null;
            if (!empty($_FILES['contacts']['name'][$index]['card_file'])) {
                $fileData = [
                    'name' => $_FILES['contacts']['name'][$index]['card_file'],
                    'type' => $_FILES['contacts']['type'][$index]['card_file'],
                    'tmp_name' => $_FILES['contacts']['tmp_name'][$index]['card_file'],
                    'error' => $_FILES['contacts']['error'][$index]['card_file'],
                    'size' => $_FILES['contacts']['size'][$index]['card_file']
                ];
                $cardPath = uploadFile($fileData, 'leads/cards');
            }

            $stmtContact->execute([
                $id, $c['type'], $c['name'], $c['designation'] ?: null, $c['mobile'], $c['alt_mobile'] ?: null, $c['whatsapp'] ?: null, $c['email'] ?: null, $cardPath, isset($c['is_primary']) ? $c['is_primary'] : 0
            ]);
        }
    }

    // 3. Refresh Products
    db()->prepare("DELETE FROM lead_interested_products WHERE lead_id = ?")->execute([$id]);
    if (!empty($_POST['interested_products'])) {
        $stmtProd = db()->prepare("INSERT INTO lead_interested_products (lead_id, product_name) VALUES (?,?)");
        foreach ($_POST['interested_products'] as $p) {
            $stmtProd->execute([$id, $p]);
        }
    }

    // 4. Activity Log
    db()->prepare("INSERT INTO lead_timeline (lead_id, user_id, action_type, description) VALUES (?,?,?,?)")
      ->execute([$id, $_SESSION['user_id'], 'Updated', 'Lead details updated.']);

    db()->commit();

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(['status' => 'success', 'message' => 'Lead updated successfully']);
        exit;
    }

    setFlash('success', 'Lead updated successfully.');
    header("Location: view.php?id=$id");

} catch (Exception $e) {
    if (db()->inTransaction()) db()->rollBack();
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        http_response_code(200); // Keep 200 so fetch doesn't throw
        echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $e->getMessage()]);
        exit;
    }
    setFlash('danger', 'Update failed: ' . $e->getMessage());
    header("Location: edit.php?id=$id");
}
exit;
