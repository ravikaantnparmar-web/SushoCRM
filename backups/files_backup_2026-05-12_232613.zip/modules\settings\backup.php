<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireRole(['super_admin', 'admin']);

$pageTitle = 'System Backup';
$db = db();

// Ensure backup directory exists
$backupDir = __DIR__ . '/../../backups/';
if (!is_dir($backupDir)) mkdir($backupDir, 0775, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $timestamp = date('Y-m-d_His');
    
    if ($action === 'backup_db') {
        $filename = 'db_backup_' . $timestamp . '.sql';
        $filePath = $backupDir . $filename;
        
        try {
            // Simple PHP-based SQL dump for portability
            $tables = [];
            $result = $db->query("SHOW TABLES");
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $tables[] = $row[0];
            }
            
            $sqlDump = "-- SushobhaCRM Database Backup\n";
            $sqlDump .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
            
            foreach ($tables as $table) {
                $res = $db->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
                $sqlDump .= "DROP TABLE IF EXISTS `$table`;\n" . $res[1] . ";\n\n";
                
                $rows = $db->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $row) {
                    $keys = array_keys($row);
                    $vals = array_map(function($v) use ($db) {
                        if ($v === null) return 'NULL';
                        return $db->quote($v);
                    }, array_values($row));
                    $sqlDump .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $vals) . ");\n";
                }
                $sqlDump .= "\n\n";
            }
            
            file_put_contents($filePath, $sqlDump);
            logActivity('settings', 'backup', "Database backup created: $filename");
            setFlash('success', 'Database backup created successfully: ' . $filename);
        } catch (Exception $e) {
            setFlash('danger', 'Database backup failed: ' . $e->getMessage());
        }
    } 
    elseif ($action === 'restore_db') {
        $file = $_POST['filename'];
        $filePath = $backupDir . $file;
        if (file_exists($filePath)) {
            try {
                $sql = file_get_contents($filePath);
                $db->exec($sql);
                logActivity('settings', 'restore', "Database restored from: $file");
                setFlash('success', 'Database restored successfully from ' . $file);
            } catch (Exception $e) {
                setFlash('danger', 'Database restore failed: ' . $e->getMessage());
            }
        }
    }
    elseif ($action === 'backup_files') {
        $filename = 'files_backup_' . $timestamp . '.zip';
        $filePath = $backupDir . $filename;
        
        if (!extension_loaded('zip')) {
            setFlash('danger', 'PHP Zip extension is not loaded.');
        } else {
            $zip = new ZipArchive();
            if ($zip->open($filePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                $rootPath = realpath(__DIR__ . '/../../');
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($rootPath),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );

                foreach ($files as $name => $file) {
                    if (!$file->isDir()) {
                        $filePathRelative = substr($file->getRealPath(), strlen($rootPath) + 1);
                        
                        // Exclude existing backups and some system files
                        if (strpos($filePathRelative, 'backups' . DIRECTORY_SEPARATOR) === 0) continue;
                        if (strpos($filePathRelative, '.git' . DIRECTORY_SEPARATOR) === 0) continue;
                        if (strpos($filePathRelative, 'node_modules' . DIRECTORY_SEPARATOR) === 0) continue;
                        
                        $zip->addFile($file->getRealPath(), $filePathRelative);
                    }
                }
                $zip->close();
                logActivity('settings', 'backup', "Program files backup created: $filename");
                setFlash('success', 'Files backup created successfully: ' . $filename);
            } else {
                setFlash('danger', 'Failed to create zip file.');
            }
        }
    }
    elseif ($action === 'restore_files') {
        $file = $_POST['filename'];
        $filePath = $backupDir . $file;
        if (file_exists($filePath)) {
            if (!extension_loaded('zip')) {
                setFlash('danger', 'PHP Zip extension is not loaded.');
            } else {
                $zip = new ZipArchive();
                if ($zip->open($filePath) === TRUE) {
                    $rootPath = realpath(__DIR__ . '/../../');
                    $zip->extractTo($rootPath);
                    $zip->close();
                    logActivity('settings', 'restore', "Program files restored from: $file");
                    setFlash('success', 'Program files restored successfully from ' . $file);
                } else {
                    setFlash('danger', 'Failed to open zip file.');
                }
            }
        }
    }
    elseif ($action === 'backup_full') {
        // Run both DB and Files backup
        $timestamp = date('Y-m-d_His');
        
        // 1. DB Backup
        $dbFile = 'db_backup_' . $timestamp . '.sql';
        $dbPath = $backupDir . $dbFile;
        try {
            $tables = [];
            $result = $db->query("SHOW TABLES");
            while ($row = $result->fetch(PDO::FETCH_NUM)) $tables[] = $row[0];
            $sqlDump = "-- Full System Backup - DB Part\n-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
            foreach ($tables as $table) {
                $res = $db->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
                $sqlDump .= "DROP TABLE IF EXISTS `$table`;\n" . $res[1] . ";\n\n";
                $rows = $db->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $row) {
                    $keys = array_keys($row);
                    $vals = array_map(function($v) use ($db) { return $v === null ? 'NULL' : $db->quote($v); }, array_values($row));
                    $sqlDump .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $vals) . ");\n";
                }
                $sqlDump .= "\n\n";
            }
            file_put_contents($dbPath, $sqlDump);
        } catch (Exception $e) { $errors[] = "DB Backup Failed: " . $e->getMessage(); }

        // 2. Files Backup
        $zipFile = 'files_backup_' . $timestamp . '.zip';
        $zipPath = $backupDir . $zipFile;
        if (extension_loaded('zip')) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                $rootPath = realpath(__DIR__ . '/../../');
                $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($rootPath), RecursiveIteratorIterator::LEAVES_ONLY);
                foreach ($files as $name => $file) {
                    if (!$file->isDir()) {
                        $filePathRelative = substr($file->getRealPath(), strlen($rootPath) + 1);
                        if (strpos($filePathRelative, 'backups' . DIRECTORY_SEPARATOR) === 0) continue;
                        if (strpos($filePathRelative, '.git' . DIRECTORY_SEPARATOR) === 0) continue;
                        $zip->addFile($file->getRealPath(), $filePathRelative);
                    }
                }
                $zip->close();
            } else { $errors[] = "Files Zip Failed"; }
        } else { $errors[] = "Zip extension missing"; }

        if (empty($errors)) {
            logActivity('settings', 'backup', "Full system backup created: $timestamp");
            setFlash('success', 'Full system backup (DB & Files) created successfully.');
        } else {
            setFlash('danger', 'Full backup completed with errors: ' . implode(", ", $errors));
        }
    }
    elseif ($action === 'delete') {
        $file = $_POST['filename'];
        if (file_exists($backupDir . $file)) {
            unlink($backupDir . $file);
            setFlash('success', 'Backup file deleted.');
        }
    }
    
    header('Location: backup.php');
    exit;
}

$backups = array_diff(scandir($backupDir), array('.', '..'));

// Sort by modification time descending (newest first)
usort($backups, function($a, $b) use ($backupDir) {
    return filemtime($backupDir . $b) <=> filemtime($backupDir . $a);
});

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">System Backup</div>
</div>
<div class="page-content">
<?= flashHtml() ?>

<div class="page-header">
  <div class="page-header-left">
    <h1>System Backup</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="index.php">Settings</a></li>
        <li class="breadcrumb-item active">Backup</li>
      </ol>
    </nav>
  </div>
  <div class="d-flex gap-2">
    <form method="POST" class="d-inline">
        <input type="hidden" name="action" value="backup_full">
        <button type="submit" class="btn btn-primary"><i class="bi bi-shield-fill-check me-1"></i>Full System Backup</button>
    </form>
    <div class="dropdown">
        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
            Partial Backups
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
            <li>
                <form method="POST">
                    <input type="hidden" name="action" value="backup_db">
                    <button type="submit" class="dropdown-item"><i class="bi bi-database me-2"></i>Backup DB Only</button>
                </form>
            </li>
            <li>
                <form method="POST">
                    <input type="hidden" name="action" value="backup_files">
                    <button type="submit" class="dropdown-item"><i class="bi bi-file-earmark-zip me-2"></i>Backup Files Only</button>
                </form>
            </li>
        </ul>
    </div>
  </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="crm-card">
            <div class="crm-card-body p-0">
                <table class="table crm-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>File Name</th>
                            <th>Type</th>
                            <th>Size</th>
                            <th>Created Date</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($backups)): ?>
                            <tr><td colspan="6" class="text-center text-muted py-5">No backups found. Click above to create one.</td></tr>
                        <?php else: 
                            $sn = 1;
                            foreach($backups as $file): 
                            $fullPath = $backupDir . $file;
                            $size = filesize($fullPath);
                            $type = strpos($file, 'db_') === 0 ? 'Database' : 'Program Files';
                            ?>
                            <tr>
                                <td><?= $sn++ ?></td>
                                <td class="fw-semibold text-dark"><?= e($file) ?></td>
                                <td>
                                    <span class="badge bg-<?= $type==='Database'?'info-subtle text-info':'dark-subtle text-dark' ?> border">
                                        <?= $type ?>
                                    </span>
                                </td>
                                <td><?= formatBytes($size) ?></td>
                                <td><?= date('d M Y, h:i A', filemtime($fullPath)) ?></td>
                                <td class="text-end">
                                    <div class="d-flex gap-1 justify-content-end">
                                        <a href="download_backup.php?file=<?= urlencode($file) ?>" class="btn btn-sm btn-icon btn-outline-success" title="Download"><i class="bi bi-download"></i></a>
                                        
                                        <form method="POST" class="d-inline" onsubmit="return confirm('WARNING: This will overwrite your current <?= strtolower($type) ?>. Are you absolutely sure?')">
                                            <input type="hidden" name="action" value="<?= $type==='Database'?'restore_db':'restore_files' ?>">
                                            <input type="hidden" name="filename" value="<?= e($file) ?>">
                                            <button type="submit" class="btn btn-sm btn-icon btn-outline-warning" title="Restore"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        </form>

                                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this backup file?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="filename" value="<?= e($file) ?>">
                                            <button type="submit" class="btn btn-sm btn-icon btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</div></div>

<?php 
function formatBytes($b) {
    if ($b >= 1073741824) return number_format($b / 1073741824, 2) . ' GB';
    if ($b >= 1048576)    return number_format($b / 1048576, 2) . ' MB';
    if ($b >= 1024)       return number_format($b / 1024, 2) . ' KB';
    return $b . ' B';
}
include __DIR__ . '/../../includes/footer.php'; 
?>
