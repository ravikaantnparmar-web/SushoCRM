<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM quotations WHERE id=?");
$stmt->execute([$id]);
$q = $stmt->fetch();
if (!$q) { setFlash('danger','Quotation not found.'); header('Location: '.BASE_URL.'/modules/quotations/index.php'); exit; }

db()->prepare("DELETE FROM quotations WHERE id=?")->execute([$id]);
logActivity('quotations','delete',"Deleted quotation: {$q['quote_number']}",$id);
setFlash('success',"Quotation '{$q['quote_number']}' deleted.");
header('Location: '.BASE_URL.'/modules/quotations/index.php');
exit;
