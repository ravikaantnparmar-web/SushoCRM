<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Kanban Board';

// Fetch all active tasks or filtered tasks
$search = sanitize($_GET['search'] ?? '');
$assignee = (int)($_GET['assignee'] ?? 0);

$where = ['1=1'];
$params = [];
if ($search) {
    $where[] = '(t.title LIKE ? OR t.description LIKE ?)';
    $params = array_merge($params, ["%$search%", "%$search%"]);
}
if (!isAdmin()) {
    $where[] = '(t.assigned_to = ? OR t.created_by = ?)';
    $params[] = $_SESSION['user_id'];
    $params[] = $_SESSION['user_id'];
}
if ($assignee) {
    $where[] = 't.assigned_to = ?';
    $params[] = $assignee;
}
$whereStr = implode(' AND ', $where);

$stmt = db()->prepare("SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON t.assigned_to = u.id WHERE $whereStr ORDER BY t.priority DESC, t.due_date ASC");
$stmt->execute($params);
$all_tasks = $stmt->fetchAll();

// Group tasks by status
$kanban = [
    'pending' => [],
    'in_progress' => [],
    'completed' => [],
    'cancelled' => []
];

foreach ($all_tasks as $t) {
    if (isset($kanban[$t['status']])) {
        $kanban[$t['status']][] = $t;
    }
}

$users = db()->query("SELECT id, name FROM users ORDER BY name ASC")->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>
<!-- Include SortableJS for drag and drop -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>

<style>
.kanban-board {
    display: flex;
    gap: 1.5rem;
    overflow-x: auto;
    padding-bottom: 1rem;
    min-height: calc(100vh - 250px);
    align-items: flex-start;
}
.kanban-col {
    background: #f4f6f9;
    border-radius: 8px;
    min-width: 300px;
    max-width: 300px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 200px);
}
.kanban-col-header {
    padding: 1rem;
    border-bottom: 2px solid #e9ecef;
    font-weight: 700;
    font-size: 1.1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.kanban-col-body {
    padding: 1rem;
    overflow-y: auto;
    flex-grow: 1;
    min-height: 150px;
}
.kanban-card {
    background: #fff;
    border-radius: 6px;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.04);
    border: 1px solid #e9ecef;
    border-left: 4px solid #6c757d;
    cursor: grab;
    transition: transform 0.2s, box-shadow 0.2s;
}
.kanban-card:active {
    cursor: grabbing;
}
.kanban-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.08);
}
.kanban-card.priority-low { border-left-color: #0dcaf0; }
.kanban-card.priority-medium { border-left-color: #0d6efd; }
.kanban-card.priority-high { border-left-color: #ffc107; }
.kanban-card.priority-urgent { border-left-color: #dc3545; }

.kanban-card-title {
    font-weight: 600;
    margin-bottom: 0.5rem;
    font-size: 0.95rem;
}
.kanban-card-title a {
    color: #212529;
    text-decoration: none;
}
.kanban-card-title a:hover {
    color: #0d6efd;
}
.kanban-card-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.75rem;
    color: #6c757d;
}
.sortable-ghost {
    opacity: 0.4;
    background-color: #e9ecef;
}
.sortable-drag {
    background-color: #fff;
    box-shadow: 0 10px 20px rgba(0,0,0,0.15);
}

/* Col Colors */
.col-pending .kanban-col-header { border-bottom-color: #6c757d; }
.col-in_progress .kanban-col-header { border-bottom-color: #0d6efd; }
.col-completed .kanban-col-header { border-bottom-color: #198754; }
.col-cancelled .kanban-col-header { border-bottom-color: #dc3545; }
</style>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Kanban Board</div>
</div>
<div class="page-content">
<?= flashHtml() ?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <h1 class="h3 mb-0 fw-bold">Kanban Board</h1>
    <form method="GET" class="d-flex gap-2">
        <select name="assignee" class="form-select form-select-sm" style="width:150px">
            <option value="">All Assignees</option>
            <?php foreach($users as $u): ?>
                <option value="<?= $u['id'] ?>" <?= $assignee==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <div class="input-group input-group-sm" style="width:200px">
            <input type="text" name="search" class="form-control" placeholder="Search tasks..." value="<?= e($search) ?>">
            <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
        </div>
        <?php if($search||$assignee): ?><a href="<?= BASE_URL ?>/modules/tasks/kanban.php" class="btn btn-sm btn-outline-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="kanban-board">
    <?php 
    $columns = [
        'pending' => ['title' => 'Pending', 'icon' => 'bi-hourglass-split', 'count' => count($kanban['pending'])],
        'in_progress' => ['title' => 'In Progress', 'icon' => 'bi-gear-fill', 'count' => count($kanban['in_progress'])],
        'completed' => ['title' => 'Completed', 'icon' => 'bi-check-circle-fill', 'count' => count($kanban['completed'])],
        'cancelled' => ['title' => 'Cancelled', 'icon' => 'bi-x-circle-fill', 'count' => count($kanban['cancelled'])]
    ];
    
    foreach ($columns as $status => $col): 
    ?>
    <div class="kanban-col col-<?= $status ?>" data-status="<?= $status ?>">
        <div class="kanban-col-header">
            <span><i class="bi <?= $col['icon'] ?> me-2"></i><?= $col['title'] ?></span>
            <span class="badge bg-secondary rounded-pill" id="count-<?= $status ?>"><?= $col['count'] ?></span>
        </div>
        <div class="kanban-col-body" id="col-<?= $status ?>">
            <?php foreach ($kanban[$status] as $t): ?>
            <div class="kanban-card priority-<?= $t['priority'] ?>" data-id="<?= $t['id'] ?>">
                <div class="kanban-card-title">
                    <a href="<?= BASE_URL ?>/modules/tasks/view.php?id=<?= $t['id'] ?>"><?= e($t['title']) ?></a>
                </div>
                <?php if($t['related_module']): ?>
                    <div class="mb-2"><span class="badge bg-light text-dark border" style="font-size:0.65rem;"><?= ucfirst($t['related_module']) ?> #<?= $t['related_id'] ?></span></div>
                <?php endif; ?>
                <div class="kanban-card-meta mt-2 pt-2 border-top">
                    <div>
                        <?php if($t['assignee_name']): ?>
                            <i class="bi bi-person-circle text-primary me-1"></i><?= e(explode(' ', $t['assignee_name'])[0]) ?>
                        <?php else: ?>
                            <span class="fst-italic">Unassigned</span>
                        <?php endif; ?>
                    </div>
                    <?php if($t['due_date']): ?>
                        <div class="<?= ($t['due_date'] < date('Y-m-d') && $status !== 'completed') ? 'text-danger fw-bold' : '' ?>">
                            <i class="bi bi-calendar3 me-1"></i><?= date('M d', strtotime($t['due_date'])) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

</div></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const columns = ['pending', 'in_progress', 'completed', 'cancelled'];
    
    columns.forEach(status => {
        new Sortable(document.getElementById('col-' + status), {
            group: 'kanban',
            animation: 150,
            ghostClass: 'sortable-ghost',
            dragClass: 'sortable-drag',
            onEnd: function (evt) {
                const itemEl = evt.item;
                const taskId = itemEl.getAttribute('data-id');
                const newStatus = evt.to.closest('.kanban-col').getAttribute('data-status');
                const oldStatus = evt.from.closest('.kanban-col').getAttribute('data-status');
                
                if (newStatus !== oldStatus) {
                    // Update counts
                    document.getElementById('count-' + oldStatus).textContent = evt.from.children.length;
                    document.getElementById('count-' + newStatus).textContent = evt.to.children.length;
                    
                    // Send AJAX request to update DB
                    const formData = new FormData();
                    formData.append('task_id', taskId);
                    formData.append('status', newStatus);
                    
                    fetch('<?= BASE_URL ?>/modules/tasks/update_status.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (!data.success) {
                            alert('Failed to update task status: ' + data.message);
                            // Revert move
                            evt.from.insertBefore(itemEl, evt.from.children[evt.oldIndex]);
                            document.getElementById('count-' + oldStatus).textContent = evt.from.children.length;
                            document.getElementById('count-' + newStatus).textContent = evt.to.children.length;
                        }
                    })
                    .catch(err => {
                        console.error('Error:', err);
                        alert('An error occurred while communicating with the server.');
                        // Revert move
                        evt.from.insertBefore(itemEl, evt.from.children[evt.oldIndex]);
                        document.getElementById('count-' + oldStatus).textContent = evt.from.children.length;
                        document.getElementById('count-' + newStatus).textContent = evt.to.children.length;
                    });
                }
            }
        });
    });
});
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
