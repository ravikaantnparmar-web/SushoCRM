<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Tasks';
$search = sanitize($_GET['search'] ?? '');
$status = sanitize($_GET['status'] ?? '');
$priority = sanitize($_GET['priority'] ?? '');
$page   = max(1,(int)($_GET['page'] ?? 1));
$per    = RECORDS_PER_PAGE;

$where = ['1=1']; $params = [];
if (!isAdmin()) {
    $where[] = '(t.assigned_to = ? OR t.created_by = ?)';
    $params[] = $_SESSION['user_id'];
    $params[] = $_SESSION['user_id'];
}
if ($search) { $where[] = '(t.title LIKE ? OR t.description LIKE ?)'; $params = array_merge($params, ["%$search%","%$search%"]); }
if ($status) { $where[] = 't.status = ?'; $params[] = $status; }
if ($priority) { $where[] = 't.priority = ?'; $params[] = $priority; }

$whereStr = implode(' AND ', $where);

$total = db()->prepare("SELECT COUNT(*) FROM tasks t WHERE $whereStr");
$total->execute($params); $totalCount = $total->fetchColumn();
$pag = paginate($totalCount, $per, $page, BASE_URL.'/modules/tasks/index.php?search='.urlencode($search).'&status='.urlencode($status).'&priority='.urlencode($priority));

$stmt = db()->prepare("SELECT t.*, u.name AS assignee_name, c.name AS creator_name FROM tasks t LEFT JOIN users u ON t.assigned_to = u.id LEFT JOIN users c ON t.created_by = c.id WHERE $whereStr ORDER BY t.due_date ASC, t.created_at DESC LIMIT $per OFFSET {$pag['offset']}");
$stmt->execute($params);
$tasks = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Tasks</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<div class="page-header">
  <div class="page-header-left"><h1>Tasks</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item active">Tasks</li></ol></nav>
  </div>
  <div>
    <a href="<?= BASE_URL ?>/modules/tasks/kanban.php" class="btn btn-outline-primary"><i class="bi bi-kanban me-1"></i>Kanban Board</a>
    <a href="<?= BASE_URL ?>/modules/tasks/create.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>New Task</a>
  </div>
</div>

<div class="table-wrapper">
  <div class="table-toolbar">
    <form method="GET" class="d-flex gap-2 flex-wrap">
      <div class="table-search"><i class="bi bi-search"></i><input type="text" name="search" placeholder="Search tasks..." value="<?= e($search) ?>"></div>
      <select name="status" class="form-select form-select-sm" style="width:130px">
        <option value="">All Status</option>
        <?php foreach(['pending','in_progress','completed','cancelled'] as $s): ?>
          <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="priority" class="form-select form-select-sm" style="width:130px">
        <option value="">All Priority</option>
        <?php foreach(['low','medium','high','urgent'] as $p): ?>
          <option value="<?= $p ?>" <?= $priority===$p?'selected':'' ?>><?= ucfirst($p) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-sm btn-primary" type="submit"><i class="bi bi-search"></i></button>
      <?php if($search||$status||$priority): ?><a href="<?= BASE_URL ?>/modules/tasks/index.php" class="btn btn-sm btn-outline-secondary">Clear</a><?php endif; ?>
    </form>
    <span class="text-muted small align-self-center"><?= number_format($totalCount) ?> tasks</span>
  </div>
  <div class="table-responsive">
    <table class="table crm-table mb-0">
      <thead><tr><th>Task</th><th>Assigned To</th><th>Due Date</th><th>Priority</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php if(empty($tasks)): ?>
          <tr><td colspan="6"><div class="empty-state"><i class="bi bi-check2-square"></i><p>No tasks found</p><a href="<?= BASE_URL ?>/modules/tasks/create.php" class="btn btn-primary btn-sm">Create Task</a></div></td></tr>
        <?php else: foreach($tasks as $t): ?>
        <tr>
          <td>
            <a href="<?= BASE_URL ?>/modules/tasks/view.php?id=<?= $t['id'] ?>" class="fw-semibold text-primary d-block"><?= e($t['title']) ?></a>
            <?php if($t['related_module']): ?>
              <span class="badge bg-light text-dark border mt-1" style="font-size:0.7rem;"><?= ucfirst($t['related_module']) ?> #<?= $t['related_id'] ?></span>
            <?php endif; ?>
          </td>
          <td>
            <div class="d-flex align-items-center">
              <?php if($t['assignee_name']): ?>
                <div class="avatar-sm bg-primary text-white rounded-circle me-2 d-flex justify-content-center align-items-center" style="width:28px;height:28px;font-size:0.8rem;"><?= strtoupper(substr($t['assignee_name'],0,1)) ?></div>
                <?= e($t['assignee_name']) ?>
              <?php else: ?>
                <span class="text-muted fst-italic">Unassigned</span>
              <?php endif; ?>
            </div>
          </td>
          <td>
            <?php 
              $isOverdue = ($t['due_date'] && $t['due_date'] < date('Y-m-d') && $t['status'] !== 'completed');
            ?>
            <span class="<?= $isOverdue ? 'text-danger fw-bold' : '' ?>">
              <?= $t['due_date'] ? formatDate($t['due_date']) : '<span class="text-muted">No Date</span>' ?>
            </span>
          </td>
          <td>
            <?php
              $pClasses = ['low'=>'bg-info','medium'=>'bg-primary','high'=>'bg-warning text-dark','urgent'=>'bg-danger'];
              $pClass = $pClasses[$t['priority']] ?? 'bg-secondary';
            ?>
            <span class="badge <?= $pClass ?>"><?= ucfirst($t['priority']) ?></span>
          </td>
          <td><?= statusBadge($t['status']) ?></td>
          <td>
            <div class="d-flex gap-1">
              <a href="<?= BASE_URL ?>/modules/tasks/edit.php?id=<?= $t['id'] ?>" class="btn btn-icon btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
              <a href="<?= BASE_URL ?>/modules/tasks/delete.php?id=<?= $t['id'] ?>" class="btn btn-icon btn-sm btn-outline-danger" data-confirm="Delete task <?= e($t['title']) ?>?"><i class="bi bi-trash"></i></a>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($pag['total_pages']>1): ?>
  <div class="d-flex justify-content-between align-items-center px-4 py-3 border-top">
    <small class="text-muted">Showing <?= $pag['offset']+1 ?>–<?= min($pag['offset']+$per,$totalCount) ?> of <?= $totalCount ?></small>
    <?= paginationHtml($pag) ?>
  </div>
  <?php endif; ?>
</div>
</div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
