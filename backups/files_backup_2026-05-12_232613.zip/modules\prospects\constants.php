<?php
// Lead Management Dropdown Constants

$siteStages = [
    'Blueprint', 'Estimation Stage', '3D Discussion', 'Interior Work', 'False Ceiling Work',
    'Modular Kitchen', 'Bedroom Work', 'Living Hall', 'Bath & Toilet Installation',
    'Glass Work', 'Flooring Work', 'Painting Work', 'Electrical Work', 'Plumbing Work',
    'Final Finishing', 'Renovation Work', 'Possession Stage'
];

$projectTypes = [
    'Residential', 'Commercial', 'Industrial', 'Institutional', 'Real Estate',
    'Turnkey', 'Hospitality', 'Renovation', 'Interior', 'Landscape', 'PMC', 'Design Consultancy'
];

$leadTypes = [
    'Website', 'Instagram', 'Facebook', 'Google Ads', 'WhatsApp', 'Referral',
    'Dealer Network', 'Exhibition', 'Cold Calling', 'Export Inquiry'
];

$leadSources = [
    'Digital Marketing', 'Architect', 'Builder', 'Contractor', 'Google Ads',
    'Instagram', 'Facebook', 'Offline Marketing', 'Exhibition', 'Newspaper',
    'Referral', 'Dealer', 'Employee', 'Existing Customer'
];

$leadPriorities = [
    'Cold Lead', 'Warm Lead', 'Hot Lead', 'Qualified Lead', 'Converted Lead', 'Hold Lead', 'Lost Lead'
];

$leadStatuses = [
    'Open', 'New', 'Contact Attempt', 'Contacted', 'Followup', 'Qualified',
    'Proposal Sent', 'Catalogue Sent', 'Negotiation', 'Won', 'Closed', 'Lost', 'Duplicate', 'Junk'
];

$companyTypes = ['Individual', 'Partnership', 'Pvt Ltd', 'Ltd'];
$industryTypes = ['Manufacturing', 'Trading', 'Service', 'Retail', 'Wholesale'];
$businessCategories = ['B2B', 'B2C', 'D2C', 'Export', 'Import'];

$designations = [
    'Owner', 'Entrepreneur', 'Manager', 'Architect', 'Engineer', 'Contractor',
    'Purchase Head', 'Site Supervisor', 'Other'
];

$productTypes = ['Bespoke', 'Turnkey'];

$interestedProducts = [
    'Partition Systems', 'Shower Enclosures', 'Flush Doors', 'Cabinets & Storage Solutions',
    'Illuminated Walls', 'Glass Surface', 'LED Mirrors', 'Modular Kitchen', 'Wardrobe',
    'Vanity Units', 'Decorative Panels', 'Office Partitions'
];

$meetingStatuses = ['Scheduled', 'Completed', 'Postponed', 'Cancelled', 'Rescheduled'];
$meetingTypes = [
    'Site Visit', 'Quotation Review', 'Negotiation', 'Project Review', 'Follow-up',
    'Dealer Network', 'Online Meeting', 'Client Discussion', 'Material Discussion'
];

$salesStages = [
    'Inquiry', 'Qualification', 'Requirement Gathering', 'Proposal', 'Negotiation',
    'Conversion', 'Execution', 'Completed'
];
