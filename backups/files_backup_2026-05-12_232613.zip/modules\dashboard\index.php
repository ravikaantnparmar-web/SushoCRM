<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Dashboard';
$pdo = db();

// ── KPI Stats ──────────────────────────────────────────────────
$totalCustomers  = $pdo->query("SELECT COUNT(*) FROM customers WHERE status='active'")->fetchColumn();
$totalProspects  = $pdo->query("SELECT COUNT(*) FROM leads WHERE lead_status NOT IN ('Won','Closed','Lost') AND deleted_at IS NULL")->fetchColumn();
$pendingQuotes   = $pdo->query("SELECT COUNT(*) FROM quotations WHERE status IN ('draft','sent')")->fetchColumn();
$openOrders      = $pdo->query("SELECT COUNT(*) FROM orders WHERE status NOT IN ('delivered','cancelled')")->fetchColumn();
$overdueInvoices = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status IN ('sent','partial') AND due_date < CURDATE()")->fetchColumn();
$monthRevenue    = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE())")->fetchColumn();
$monthExpenses   = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE MONTH(expense_date)=MONTH(CURDATE()) AND YEAR(expense_date)=YEAR(CURDATE())")->fetchColumn();
$totalEmployees  = $pdo->query("SELECT COUNT(*) FROM employees WHERE status='active'")->fetchColumn();

// ── Monthly Revenue chart (last 12 months) ─────────────────────
$revenueRows = $pdo->query("
    SELECT DATE_FORMAT(payment_date,'%b %Y') AS label,
           DATE_FORMAT(payment_date,'%Y-%m') AS ym,
           SUM(amount) AS total
    FROM payments
    WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY ym, label
    ORDER BY ym ASC
")->fetchAll();
$chartLabels  = json_encode(array_column($revenueRows, 'label'));
$chartRevenue = json_encode(array_map('floatval', array_column($revenueRows, 'total')));

// ── Expense by category ────────────────────────────────────────
$expCatRows = $pdo->query("
    SELECT ec.name AS label, SUM(e.amount) AS total
    FROM expenses e JOIN expense_categories ec ON e.category_id=ec.id
    WHERE YEAR(e.expense_date)=YEAR(CURDATE())
    GROUP BY ec.id ORDER BY total DESC LIMIT 6
")->fetchAll();
$expLabels = json_encode(array_column($expCatRows, 'label'));
$expData   = json_encode(array_map('floatval', array_column($expCatRows, 'total')));

// ── Recent Invoices ────────────────────────────────────────────
$recentInvoices = $pdo->query("
    SELECT i.*, c.name AS customer_name
    FROM invoices i JOIN customers c ON i.customer_id=c.id
    ORDER BY i.created_at DESC LIMIT 8
")->fetchAll();

// ── Top Customers ──────────────────────────────────────────────
$topCustomers = $pdo->query("
    SELECT c.name, SUM(p.amount) AS total_paid
    FROM payments p JOIN customers c ON p.customer_id=c.id
    GROUP BY c.id ORDER BY total_paid DESC LIMIT 5
")->fetchAll();

// ── Pending Tasks ──────────────────────────────────────────────
$pendingTasks = $pdo->query("
    SELECT t.*, u.name AS assigned_name
    FROM tasks t LEFT JOIN users u ON t.assigned_to=u.id
    WHERE t.status IN ('pending','in_progress') ORDER BY t.due_date ASC LIMIT 5
")->fetchAll();

// ── Activity Feed ──────────────────────────────────────────────
$activityFeed = $pdo->query("
    SELECT al.*, u.name AS user_name
    FROM activity_logs al LEFT JOIN users u ON al.user_id=u.id
    ORDER BY al.created_at DESC LIMIT 8
")->fetchAll();

// ── Announcements (Communication Board) ────────────────────────
$announcements = $pdo->query("
    SELECT a.*, u.name AS author 
    FROM announcements a 
    LEFT JOIN users u ON a.created_by = u.id 
    WHERE a.is_active = 1 
    ORDER BY a.priority DESC, a.created_at DESC
")->fetchAll();

$showAnnouncements = false;
if (!empty($announcements) && !isset($_SESSION['announcement_shown'])) {
    $showAnnouncements = true;
    $_SESSION['announcement_shown'] = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_comment'])) {
    $announcement_id = (int)$_POST['announcement_id'];
    $comment = sanitize($_POST['comment']);
    if ($announcement_id && $comment) {
        $stmt = $pdo->prepare("INSERT INTO announcement_comments (announcement_id, user_id, comment) VALUES (?, ?, ?)");
        $stmt->execute([$announcement_id, $_SESSION['user_id'], $comment]);
        setFlash('success', 'Comment posted.');
        header('Location: index.php');
        exit;
    }
}

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>

<div class="main-content">
  <!-- Topbar -->
  <div class="topbar">
    <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
    <div class="topbar-title">Dashboard</div>
    <div class="topbar-right">
      <!-- Notification Bell -->
      <div class="dropdown">
        <button class="notif-btn" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php if ($notifCount > 0): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?>
        </button>
        <div class="dropdown-menu dropdown-menu-end p-0" style="width:300px;border-radius:12px;overflow:hidden;box-shadow:var(--shadow-md)">
          <div class="bg-primary text-white p-3 d-flex justify-content-between align-items-center">
            <span class="fw-semibold">Notifications</span>
            <?php if($notifCount>0): ?><span class="badge bg-light text-primary"><?= $notifCount ?> new</span><?php endif; ?>
          </div>
          <div style="max-height:300px;overflow-y:auto">
            <?php if (empty($notifs)): ?>
              <div class="p-3 text-center text-muted small">No new notifications</div>
            <?php else: foreach ($notifs as $n): ?>
              <a href="<?= BASE_URL . e($n['link'] ?? '#') ?>" class="d-flex align-items-start gap-2 p-3 text-decoration-none border-bottom hover-bg">
                <span class="badge bg-<?= e($n['type']) ?> mt-1" style="font-size:8px;padding:5px">●</span>
                <div>
                  <div class="small fw-semibold text-dark"><?= e($n['title']) ?></div>
                  <div class="text-muted" style="font-size:11px"><?= e($n['message']) ?></div>
                </div>
              </a>
            <?php endforeach; endif; ?>
          </div>
        </div>
      </div>
      <!-- User dropdown -->
      <div class="dropdown">
        <button class="btn btn-sm d-flex align-items-center gap-2" data-bs-toggle="dropdown"
                style="background:var(--bg-main);border:1px solid var(--border-color);border-radius:8px;padding:5px 10px">
          <div class="stat-icon primary" style="width:28px;height:28px;border-radius:8px;font-size:12px">
            <?= strtoupper(substr($currentUser['name'] ?? 'U', 0, 1)) ?>
          </div>
          <span class="small fw-semibold d-none d-md-inline"><?= e($currentUser['name'] ?? '') ?></span>
          <i class="bi bi-chevron-down small"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end" style="border-radius:10px">
          <li><a class="dropdown-item small" href="<?= BASE_URL ?>/modules/settings/users.php"><i class="bi bi-person me-2"></i>Profile</a></li>
          <li><a class="dropdown-item small" href="<?= BASE_URL ?>/modules/settings/index.php"><i class="bi bi-gear me-2"></i>Settings</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item small text-danger" href="<?= BASE_URL ?>/modules/auth/logout.php"><i class="bi bi-box-arrow-left me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="page-content">
    <!-- Page Header -->
    <div class="page-header">
      <div class="page-header-left">
        <h1>Dashboard</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
          <li class="breadcrumb-item active">Home</li>
        </ol></nav>
      </div>
      <div class="text-muted small"><i class="bi bi-calendar3 me-1"></i><?= date('l, d F Y') ?></div>
      <a href="<?= BASE_URL ?>/modules/dashboard/create.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>New Dashboard</a>
</div>

    <!-- Flash Messages -->
    <?= flashHtml() ?>

    <!-- ── KPI STATS ──────────────────────────────────────────── -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card primary">
          <div class="stat-icon primary"><i class="bi bi-people-fill"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= number_format($totalCustomers) ?></div>
            <div class="stat-label">Total Customers</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card success">
          <div class="stat-icon success"><i class="bi bi-currency-rupee"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= formatCurrency($monthRevenue) ?></div>
            <div class="stat-label">Revenue This Month</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card warning">
          <div class="stat-icon warning"><i class="bi bi-file-text-fill"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= $pendingQuotes ?></div>
            <div class="stat-label">Pending Quotations</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card danger">
          <div class="stat-icon danger"><i class="bi bi-cart-fill"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= $openOrders ?></div>
            <div class="stat-label">Open Orders</div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card info">
          <div class="stat-icon info"><i class="bi bi-funnel-fill"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= $totalProspects ?></div>
            <div class="stat-label">Active Leads</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card danger">
          <div class="stat-icon danger"><i class="bi bi-receipt-cutoff"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= $overdueInvoices ?></div>
            <div class="stat-label">Overdue Invoices</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card warning">
          <div class="stat-icon warning"><i class="bi bi-cash-stack"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= formatCurrency($monthExpenses) ?></div>
            <div class="stat-label">Expenses This Month</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card success">
          <div class="stat-icon success"><i class="bi bi-person-badge-fill"></i></div>
          <div class="stat-info">
            <div class="stat-value"><?= $totalEmployees ?></div>
            <div class="stat-label">Active Employees</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── CHARTS ─────────────────────────────────────────────── -->
    <div class="row g-3 mb-4">
      <div class="col-12 col-lg-8">
        <div class="crm-card h-100">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-bar-chart-fill text-primary me-2"></i>Monthly Revenue (Last 12 Months)</h2>
          </div>
          <div class="crm-card-body">
            <div class="chart-container" style="height:260px">
              <canvas id="revenueChart"></canvas>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-4">
        <div class="crm-card h-100">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-pie-chart-fill text-warning me-2"></i>Expenses by Category</h2>
          </div>
          <div class="crm-card-body">
            <div class="chart-container" style="height:260px">
              <canvas id="expenseChart"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── RECENT INVOICES + TOP CUSTOMERS ───────────────────── -->
    <div class="row g-3 mb-4">
      <div class="col-12 col-lg-8">
        <div class="crm-card">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-receipt-cutoff text-success me-2"></i>Recent Invoices</h2>
            <a href="<?= BASE_URL ?>/modules/invoices/index.php" class="btn btn-sm btn-outline-primary">View All</a>
          </div>
          <div class="table-responsive">
            <table class="table crm-table mb-0">
              <thead><tr>
                <th>Invoice #</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th>
              </tr></thead>
              <tbody>
                <?php foreach ($recentInvoices as $inv): ?>
                <tr>
                  <td><a href="<?= BASE_URL ?>/modules/invoices/view.php?id=<?= $inv['id'] ?>" class="text-primary fw-semibold"><?= e($inv['invoice_number']) ?></a></td>
                  <td><?= e($inv['customer_name']) ?></td>
                  <td><?= formatDate($inv['issued_date']) ?></td>
                  <td class="fw-semibold"><?= formatCurrency($inv['total']) ?></td>
                  <td><?= statusBadge($inv['status']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recentInvoices)): ?>
                  <tr><td colspan="5" class="text-center text-muted py-4">No invoices yet</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-12 col-lg-4">
        <div class="crm-card h-100">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-trophy-fill text-warning me-2"></i>Top Customers</h2>
          </div>
          <div class="crm-card-body p-0">
            <?php if (empty($topCustomers)): ?>
              <div class="text-center text-muted p-4 small">No data yet</div>
            <?php else: ?>
              <?php $maxRevenue = max(array_column($topCustomers,'total_paid')) ?: 1; ?>
              <?php foreach ($topCustomers as $idx => $c): ?>
              <div class="px-4 py-3 border-bottom">
                <div class="d-flex justify-content-between align-items-center mb-1">
                  <div class="d-flex align-items-center gap-2">
                    <div class="stat-icon primary" style="width:28px;height:28px;border-radius:8px;font-size:11px;flex-shrink:0">
                      <?= ($idx+1) ?>
                    </div>
                    <span class="fw-semibold small"><?= e($c['name']) ?></span>
                  </div>
                  <span class="small fw-bold text-success"><?= formatCurrency($c['total_paid']) ?></span>
                </div>
                <div class="progress" style="height:4px;border-radius:4px">
                  <div class="progress-bar bg-primary" style="width:<?= round($c['total_paid']/$maxRevenue*100) ?>%"></div>
                </div>
              </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- ── TASKS + ACTIVITY ───────────────────────────────────── -->
    <div class="row g-3">
      <div class="col-12 col-lg-6">
        <div class="crm-card">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-check2-square text-primary me-2"></i>Pending Tasks</h2>
            <span class="badge bg-warning"><?= count($pendingTasks) ?></span>
          </div>
          <div class="crm-card-body p-0">
            <?php if (empty($pendingTasks)): ?>
              <div class="empty-state"><i class="bi bi-check-all"></i><p>All tasks completed!</p></div>
            <?php else: foreach ($pendingTasks as $task): ?>
              <div class="d-flex align-items-start gap-3 px-4 py-3 border-bottom">
                <div class="mt-1"><?= statusBadge($task['priority']) ?></div>
                <div class="flex-grow-1">
                  <div class="fw-semibold small"><?= e($task['title']) ?></div>
                  <div class="text-muted" style="font-size:11px">
                    <?php if ($task['assigned_name']): ?><i class="bi bi-person me-1"></i><?= e($task['assigned_name']) ?> · <?php endif; ?>
                    <?php if ($task['due_date']): ?>
                      <i class="bi bi-calendar3 me-1"></i>
                      <span class="<?= strtotime($task['due_date']) < time() ? 'text-danger fw-semibold' : '' ?>">
                        <?= formatDate($task['due_date']) ?>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>
                <?= statusBadge($task['status']) ?>
              </div>
            <?php endforeach; endif; ?>
          </div>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="crm-card">
          <div class="crm-card-header">
            <h2 class="crm-card-title"><i class="bi bi-clock-history text-info me-2"></i>Recent Activity</h2>
          </div>
          <div class="crm-card-body">
            <ul class="timeline">
              <?php foreach ($activityFeed as $log): ?>
              <li class="timeline-item">
                <div class="timeline-dot" style="background:var(--primary)"></div>
                <div class="timeline-content">
                  <span class="fw-semibold"><?= e($log['user_name'] ?? 'System') ?></span>
                  <span class="text-muted"> <?= e($log['description']) ?></span>
                  <div class="timeline-time"><?= formatDateTime($log['created_at']) ?></div>
                </div>
              </li>
              <?php endforeach; ?>
              <?php if (empty($activityFeed)): ?>
                <li class="text-muted small text-center py-3">No activity yet</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.page-content -->
</div><!-- /.main-content -->
</div><!-- /.app-wrapper -->

<?php if ($showAnnouncements): ?>
<!-- Communication Board Modal -->
<div class="modal fade" id="announcementModal" data-bs-backdrop="static" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content shadow-lg border-0" style="border-radius:16px; overflow:hidden;">
      <div class="modal-header bg-primary text-white border-0 py-3">
        <h5 class="modal-title fw-bold"><i class="bi bi-megaphone-fill me-2"></i>Communication Board</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0 position-relative" id="announcementBody">
        <div class="progress" style="height:4px; position:absolute; top:0; left:0; width:100%; border-radius:0; z-index:10;">
          <div id="announcementTimer" class="progress-bar bg-warning" style="width:100%; transition: width 0.1s linear;"></div>
        </div>
        
        <div id="announcementCarousel" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <?php foreach($announcements as $idx => $a): ?>
            <div class="carousel-item <?= $idx===0?'active':'' ?> p-4">
              <div class="d-flex align-items-center mb-3">
                <span class="badge bg-<?= $a['priority']=='High'?'danger':'primary' ?> me-2"><?= e($a['category']) ?></span>
                <span class="text-muted small"><?= formatDate($a['created_at']) ?> by <?= e($a['author']) ?></span>
              </div>
              <h3 class="fw-bold mb-3"><?= e($a['title']) ?></h3>
              <div class="announcement-content fs-5 mb-4" style="white-space: pre-line;">
                <?= e($a['content']) ?>
              </div>
              
              <div class="mt-4 pt-4 border-top">
                <h6 class="fw-bold mb-3 small text-uppercase text-muted">Comments</h6>
                <div class="comments-list mb-3" style="max-height:150px; overflow-y:auto;">
                  <?php
                  $comments = $pdo->prepare("SELECT ac.*, u.name FROM announcement_comments ac JOIN users u ON ac.user_id = u.id WHERE ac.announcement_id = ? ORDER BY ac.created_at ASC");
                  $comments->execute([$a['id']]);
                  $comList = $comments->fetchAll();
                  if (empty($comList)): ?>
                    <p class="text-muted small italic">No comments yet.</p>
                  <?php else: foreach($comList as $c): ?>
                    <div class="mb-2 p-2 bg-light rounded border-start border-primary border-3">
                      <div class="d-flex justify-content-between small fw-bold"><span><?= e($c['name']) ?></span><span class="text-muted" style="font-size:10px;"><?= formatDateTime($c['created_at']) ?></span></div>
                      <div class="small"><?= e($c['comment']) ?></div>
                    </div>
                  <?php endforeach; endif; ?>
                </div>
                <form method="POST" class="mt-2">
                  <input type="hidden" name="post_comment" value="1">
                  <input type="hidden" name="announcement_id" value="<?= $a['id'] ?>">
                  <div class="input-group input-group-sm">
                    <input type="text" name="comment" class="form-control" placeholder="Add a comment..." required>
                    <button class="btn btn-primary" type="submit">Post</button>
                  </div>
                </form>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <?php if (count($announcements) > 1): ?>
          <button class="carousel-control-prev" type="button" data-bs-target="#announcementCarousel" data-bs-slide="prev" style="width:5%;">
            <span class="carousel-control-prev-icon bg-dark rounded-circle" aria-hidden="true"></span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#announcementCarousel" data-bs-slide="next" style="width:5%;">
            <span class="carousel-control-next-icon bg-dark rounded-circle" aria-hidden="true"></span>
          </button>
          <?php endif; ?>
        </div>
      </div>
      <div class="modal-footer bg-light border-0 py-2 d-flex justify-content-between">
        <small class="text-muted"><i class="bi bi-info-circle me-1"></i>Dismisses in 10s. Hover to pause.</small>
        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Close Board</button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modalEl = document.getElementById('announcementModal');
    const modal = new bootstrap.Modal(modalEl);
    const progressBar = document.getElementById('announcementTimer');
    const totalTime = 10000; // 10 seconds
    let timeLeft = totalTime;
    let timerInterval;
    let isPaused = false;

    modal.show();

    function startTimer() {
        timerInterval = setInterval(() => {
            if (!isPaused) {
                timeLeft -= 100;
                const percentage = (timeLeft / totalTime) * 100;
                progressBar.style.width = percentage + '%';
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    modal.hide();
                }
            }
        }, 100);
    }

    startTimer();

    // Pause on hover
    modalEl.addEventListener('mouseenter', () => { isPaused = true; });
    modalEl.addEventListener('mouseleave', () => { isPaused = false; });
    
    // Also pause if they start typing in a comment field
    modalEl.querySelectorAll('input').forEach(input => {
        input.addEventListener('focus', () => { isPaused = true; });
    });
});
</script>
<?php endif; ?>

<!-- Charts Init -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script>
// Revenue Bar Chart
const rCtx = document.getElementById('revenueChart').getContext('2d');
new Chart(rCtx, {
  type: 'bar',
  data: {
    labels: <?= $chartLabels ?>,
    datasets: [{
      label: 'Revenue (₹)',
      data: <?= $chartRevenue ?>,
      backgroundColor: 'rgba(67,97,238,0.15)',
      borderColor: '#4361ee',
      borderWidth: 2,
      borderRadius: 6,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.05)' },
           ticks: { callback: v => '₹' + (v >= 1000 ? (v/1000)+'k' : v) } },
      x: { grid: { display: false } }
    }
  }
});

// Expense Doughnut Chart
const eCtx = document.getElementById('expenseChart').getContext('2d');
new Chart(eCtx, {
  type: 'doughnut',
  data: {
    labels: <?= $expLabels ?>,
    datasets: [{
      data: <?= $expData ?>,
      backgroundColor: ['#4361ee','#2ec4b6','#f4a261','#e63946','#4cc9f0','#7209b7'],
      borderWidth: 0,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } },
    cutout: '65%'
  }
});

// Sidebar overlay
document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);
</script>
</body></html>
