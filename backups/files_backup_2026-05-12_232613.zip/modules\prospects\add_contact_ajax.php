<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/functions.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $leadId = $_POST['lead_id'];
        $name = $_POST['name'];
        $designation = $_POST['designation'] ?: null;
        $contactType = $_POST['contact_type'] ?: 'Owner';
        $mobile = $_POST['mobile'];
        $whatsapp = $_POST['whatsapp'] ?: null;
        $email = $_POST['email'] ?: null;
        
        $cardPath = null;
        if (!empty($_FILES['visiting_card']['name'])) {
            $cardPath = uploadFile($_FILES['visiting_card'], 'uploads/leads/cards/');
        }

        $sql = "INSERT INTO lead_contacts (lead_id, contact_type, name, designation, mobile, whatsapp, email, visiting_card, is_primary) 
                VALUES (?,?,?,?,?,?,?,?,0)";
        $stmt = db()->prepare($sql);
        $stmt->execute([$leadId, $contactType, $name, $designation, $mobile, $whatsapp, $email, $cardPath]);

        echo json_encode(['status' => 'success', 'message' => 'Contact added successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
