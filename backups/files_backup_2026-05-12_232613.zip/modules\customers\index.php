<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Customers';
$search = sanitize($_GET['search'] ?? '');
$status = sanitize($_GET['status'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = RECORDS_PER_PAGE;

$where = ['1=1'];
$params = [];
if (!isAdmin()) {
    $where[] = 'c.created_by = ?';
    $params[] = $_SESSION['user_id'];
}
if ($search) { $where[] = '(c.name LIKE ? OR c.company LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.website LIKE ? OR c.whatsapp_number LIKE ?)'; $params = array_merge($params, ["%$search%","%$search%","%$search%","%$search%","%$search%","%$search%"]); }
if ($status) { $where[] = 'c.status = ?'; $params[] = $status; }
$whereStr = implode(' AND ', $where);

$total = db()->prepare("SELECT COUNT(*) FROM customers c WHERE $whereStr");
$total->execute($params);
$totalCount = $total->fetchColumn();

$pag = paginate($totalCount, $per, $page, BASE_URL . '/modules/customers/index.php?search=' . urlencode($search) . '&status=' . urlencode($status));

$stmt = db()->prepare("SELECT c.*, u.name AS created_by_name,
    (SELECT COUNT(*) FROM quotations q WHERE q.customer_id=c.id) AS quote_count,
    (SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.customer_id=c.id) AS total_paid
    FROM customers c LEFT JOIN users u ON c.created_by=u.id
    WHERE $whereStr ORDER BY c.created_at DESC LIMIT $per OFFSET {$pag['offset']}");
$stmt->execute($params);
$customers = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Customers</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Customer Management</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item active">Customers</li></ol></nav>
  </div>
  <a href="<?= BASE_URL ?>/modules/customers/create.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Customer</a>
</div>

<div class="table-wrapper">
  <div class="table-toolbar">
    <form method="GET" class="d-flex gap-2 flex-wrap">
      <div class="table-search">
        <i class="bi bi-search"></i>
        <input type="text" name="search" placeholder="Search customers..." value="<?= e($search) ?>">
      </div>
      <select name="status" class="form-select form-select-sm" style="width:130px">
        <option value="">All Status</option>
        <?php foreach(['Prospect', 'Active', 'Inactive', 'Lost', 'Blacklisted'] as $opt): ?>
          <option value="<?= $opt ?>" <?= $status===$opt?'selected':'' ?>><?= $opt ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-sm btn-primary" type="submit"><i class="bi bi-search"></i></button>
      <?php if ($search || $status): ?>
        <a href="<?= BASE_URL ?>/modules/customers/index.php" class="btn btn-sm btn-outline-secondary">Clear</a>
      <?php endif; ?>
    </form>
    <div class="d-flex gap-2">
      <span class="text-muted small align-self-center"><?= number_format($totalCount) ?> records</span>
      <button class="btn btn-sm btn-outline-secondary" onclick="exportTableToCSV('customersTable','customers.csv')"><i class="bi bi-download me-1"></i>CSV</button>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table crm-table mb-0" id="customersTable">
      <thead><tr>
        <th>#</th><th>Customer</th><th>Company</th><th>Type</th><th>Phone</th><th>City</th>
        <th>Quotes</th><th>Total Paid</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php if (empty($customers)): ?>
          <tr><td colspan="9"><div class="empty-state"><i class="bi bi-people"></i><p>No customers found</p><a href="<?= BASE_URL ?>/modules/customers/create.php" class="btn btn-primary btn-sm">Add First Customer</a></div></td></tr>
        <?php else: ?>
          <?php foreach ($customers as $i => $c): ?>
          <tr>
            <td class="text-muted small"><?= ($pag['offset']+$i+1) ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="stat-icon primary" style="width:32px;height:32px;border-radius:10px;font-size:13px;flex-shrink:0"><?= strtoupper(substr($c['name'],0,1)) ?></div>
                <div>
                  <a href="<?= BASE_URL ?>/modules/customers/view.php?id=<?= $c['id'] ?>" class="fw-semibold text-dark"><?= e($c['name']) ?></a>
                  <?php if ($c['customer_code']): ?><div class="text-muted" style="font-size:11px"><?= e($c['customer_code']) ?></div><?php endif; ?>
                </div>
              </div>
            </td>
            <td><?= e($c['company'] ?: '—') ?></td>
            <td><span class="badge bg-light text-dark border"><?= e($c['customer_type'] ?: '—') ?></span></td>
            <td><?= e($c['phone'] ?: '—') ?></td>
            <td><?= e($c['city'] ?: '—') ?></td>
            <td><span class="badge bg-primary"><?= $c['quote_count'] ?></span></td>
            <td class="fw-semibold text-success"><?= formatCurrency($c['total_paid']) ?></td>
            <td><?= statusBadge($c['status']) ?></td>
            <td>
              <div class="d-flex gap-1">
                <a href="<?= BASE_URL ?>/modules/customers/view.php?id=<?= $c['id'] ?>" class="btn btn-icon btn-sm btn-outline-info" data-bs-toggle="tooltip" title="View"><i class="bi bi-eye"></i></a>
                <a href="<?= BASE_URL ?>/modules/customers/edit.php?id=<?= $c['id'] ?>" class="btn btn-icon btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="Edit"><i class="bi bi-pencil"></i></a>
                <a href="<?= BASE_URL ?>/modules/customers/delete.php?id=<?= $c['id'] ?>" class="btn btn-icon btn-sm btn-outline-danger" data-confirm="Delete customer <?= e($c['name']) ?>?" data-bs-toggle="tooltip" title="Delete"><i class="bi bi-trash"></i></a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pag['total_pages'] > 1): ?>
  <div class="d-flex justify-content-between align-items-center px-4 py-3 border-top">
    <small class="text-muted">Showing <?= ($pag['offset']+1) ?>–<?= min($pag['offset']+$per,$totalCount) ?> of <?= $totalCount ?></small>
    <?= paginationHtml($pag) ?>
  </div>
  <?php endif; ?>
</div>
</div>
</div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
