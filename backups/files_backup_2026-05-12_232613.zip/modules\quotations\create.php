<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Create Quotation';
$errors = [];
$customers = getAllCustomers();
$products = getAllProducts();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quote_number = sanitize($_POST['quote_number'] ?? '');
    if (!$quote_number) $quote_number = generateQuoteNumber();
    $customer_id = (int)($_POST['customer_id'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'draft');
    $valid_until = sanitize($_POST['valid_until'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    $terms = sanitize($_POST['terms'] ?? '');
    $discount_type = sanitize($_POST['discount_type'] ?? 'fixed');
    $discount_value = (float)($_POST['discount_value'] ?? 0);

    // Line items array
    $items = $_POST['items'] ?? [];

    if (!$customer_id) $errors['customer_id'] = 'Please select a customer.';
    if (empty($items)) $errors['items'] = 'At least one item is required.';

    if (!$errors) {
        try {
            db()->beginTransaction();
            
            // Calculate totals
            $subtotal = 0;
            $tax_amount = 0;
            
            foreach ($items as $item) {
                $qty = (float)($item['qty'] ?? 1);
                $price = (float)($item['unit_price'] ?? 0);
                $tax_rate = (float)($item['tax_rate'] ?? 0);
                $disc = (float)($item['discount'] ?? 0); // Item level discount not used right now
                
                $line_total = $qty * $price;
                $line_tax = $line_total * ($tax_rate / 100);
                
                $subtotal += $line_total;
                $tax_amount += $line_tax;
            }
            
            $discount_amount = $discount_type === 'percent' ? ($subtotal * ($discount_value / 100)) : $discount_value;
            $total = ($subtotal - $discount_amount) + $tax_amount;

            $stmt = db()->prepare("INSERT INTO quotations (quote_number, customer_id, status, valid_until, subtotal, discount_type, discount_value, discount_amount, tax_amount, total, notes, terms, created_by)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$quote_number, $customer_id, $status, $valid_until?:null, $subtotal, $discount_type, $discount_value, $discount_amount, $tax_amount, $total, $notes, $terms, $_SESSION['user_id']]);
            $quote_id = db()->lastInsertId();

            $stmtItem = db()->prepare("INSERT INTO quotation_items (quotation_id, product_id, description, qty, unit, unit_price, tax_rate, tax_amount, discount, line_total, sort_order)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)");
            foreach ($items as $i => $item) {
                $pid = (int)($item['product_id'] ?? 0) ?: null;
                $desc = sanitize($item['description'] ?? '');
                $qty = (float)($item['qty'] ?? 1);
                $unit = sanitize($item['unit'] ?? 'Nos');
                $price = (float)($item['unit_price'] ?? 0);
                $tax_rate = (float)($item['tax_rate'] ?? 0);
                $line_total = $qty * $price;
                $line_tax = $line_total * ($tax_rate / 100);
                $stmtItem->execute([$quote_id, $pid, $desc, $qty, $unit, $price, $tax_rate, $line_tax, 0, $line_total, $i]);
            }

            db()->commit();
            logActivity('quotations','create',"Created quotation: $quote_number",$quote_id);
            setFlash('success',"Quotation '$quote_number' created.");
            header('Location: '.BASE_URL.'/modules/quotations/view.php?id='.$quote_id);
            exit;
        } catch (Exception $e) {
            db()->rollBack();
            $errors['general'] = 'An error occurred: ' . $e->getMessage();
        }
    }
}

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Create Quotation</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<?php if(isset($errors['general'])): ?><div class="alert alert-danger"><?= e($errors['general']) ?></div><?php endif; ?>
<div class="page-header">
  <div class="page-header-left"><h1>Create Quotation</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/quotations/index.php">Quotations</a></li><li class="breadcrumb-item active">Create</li></ol></nav>
  </div>
  <a href="<?= BASE_URL ?>/modules/quotations/index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>
<form method="POST" id="quoteForm">
  <div class="row g-3">
    <div class="col-lg-8">
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-file-text me-2"></i>Quote Details</div>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Quote Number</label>
            <input type="text" name="quote_number" class="form-control" value="<?= e($_POST['quote_number']??'') ?>" placeholder="Auto-generated if blank">
          </div>
          <div class="col-md-6">
            <label class="form-label">Customer <span class="text-danger">*</span></label>
            <select name="customer_id" class="form-select <?= isset($errors['customer_id'])?'is-invalid':'' ?>">
              <option value="">— Select Customer —</option>
              <?php foreach($customers as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($_POST['customer_id']??'')==$c['id']?'selected':'' ?>><?= e($c['name']) ?> <?= $c['company']?"({$c['company']})":'' ?></option>
              <?php endforeach; ?>
            </select>
            <?php if(isset($errors['customer_id'])): ?><div class="invalid-feedback"><?= $errors['customer_id'] ?></div><?php endif; ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Valid Until</label>
            <input type="date" name="valid_until" class="form-control" value="<?= e($_POST['valid_until']??date('Y-m-d', strtotime('+30 days'))) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
              <option value="draft" <?= ($_POST['status']??'draft')==='draft'?'selected':'' ?>>Draft</option>
              <option value="sent" <?= ($_POST['status']??'')==='sent'?'selected':'' ?>>Sent</option>
            </select>
          </div>
        </div>
      </div>
      
      <div class="crm-form-section">
        <div class="form-section-title d-flex justify-content-between align-items-center">
          <span><i class="bi bi-list-check me-2"></i>Line Items</span>
          <button type="button" class="btn btn-sm btn-primary" onclick="addItem()"><i class="bi bi-plus me-1"></i>Add Item</button>
        </div>
        <?php if(isset($errors['items'])): ?><div class="alert alert-danger small py-2"><?= $errors['items'] ?></div><?php endif; ?>
        <div class="table-responsive" style="overflow:visible">
          <table class="table table-bordered line-items-table" id="itemsTable">
            <thead>
              <tr class="bg-light">
                <th style="width:30%">Item / Description</th>
                <th style="width:12%">Qty</th>
                <th style="width:12%">Unit</th>
                <th style="width:15%">Unit Price</th>
                <th style="width:12%">Tax %</th>
                <th style="width:15%">Total</th>
                <th style="width:5%"></th>
              </tr>
            </thead>
            <tbody>
              <!-- Items will be injected here -->
            </tbody>
          </table>
        </div>
      </div>
      
      <div class="crm-form-section">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Notes (Internal/Customer)</label>
            <textarea name="notes" class="form-control" rows="4"><?= e($_POST['notes']??'') ?></textarea>
          </div>
          <div class="col-md-6">
            <label class="form-label">Terms & Conditions</label>
            <textarea name="terms" class="form-control" rows="4"><?= e($_POST['terms'] ?? "1. Quotation valid for 30 days.\n2. Payment: 100% advance.") ?></textarea>
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="line-total-section mb-3">
        <h5 class="mb-3 text-dark fw-bold">Summary</h5>
        <div class="line-total-row-item">
          <span>Subtotal</span>
          <span id="calcSubtotal">₹ 0.00</span>
        </div>
        <div class="line-total-row-item align-items-center mb-2">
          <span>Discount</span>
          <div class="d-flex gap-1" style="width:140px">
            <input type="number" name="discount_value" id="discountValue" class="form-control form-control-sm text-end" value="<?= e($_POST['discount_value']??'0') ?>" step="0.01" min="0" oninput="calculateTotal()">
            <select name="discount_type" id="discountType" class="form-select form-select-sm px-1" style="width:60px" onchange="calculateTotal()">
              <option value="fixed" <?= ($_POST['discount_type']??'fixed')==='fixed'?'selected':'' ?>>₹</option>
              <option value="percent" <?= ($_POST['discount_type']??'')==='percent'?'selected':'' ?>>%</option>
            </select>
          </div>
        </div>
        <div class="line-total-row-item">
          <span>Tax</span>
          <span id="calcTax">₹ 0.00</span>
        </div>
        <div class="line-total-row-item grand-total">
          <span>Total</span>
          <span id="calcTotal">₹ 0.00</span>
        </div>
      </div>
      <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Save Quotation</button>
        <a href="<?= BASE_URL ?>/modules/quotations/index.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </div>
  </div>
</form>
</div></div></div>

<script>
const products = <?= json_encode($products) ?>;
let itemIndex = 0;

function addItem() {
    const tbody = document.querySelector('#itemsTable tbody');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>
            <select name="items[${itemIndex}][product_id]" class="form-select form-select-sm mb-1 product-select" onchange="productSelected(this, ${itemIndex})">
                <option value="">— Custom Item —</option>
                ${products.map(p => `<option value="${p.id}" data-price="${p.selling_price}" data-unit="${p.unit}" data-tax="${p.tax_rate}">${p.name}</option>`).join('')}
            </select>
            <input type="text" name="items[${itemIndex}][description]" class="form-control form-control-sm item-desc" placeholder="Description" required>
        </td>
        <td><input type="number" name="items[${itemIndex}][qty]" class="form-control form-control-sm item-qty text-end" value="1" step="0.01" min="0.01" oninput="calculateTotal()" required></td>
        <td><input type="text" name="items[${itemIndex}][unit]" class="form-control form-control-sm item-unit" value="Nos"></td>
        <td><input type="number" name="items[${itemIndex}][unit_price]" class="form-control form-control-sm item-price text-end" value="0" step="0.01" min="0" oninput="calculateTotal()" required></td>
        <td><input type="number" name="items[${itemIndex}][tax_rate]" class="form-control form-control-sm item-tax text-end" value="18" step="0.01" min="0" oninput="calculateTotal()"></td>
        <td><input type="text" class="form-control form-control-sm item-total text-end bg-light" readonly value="0.00"></td>
        <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger btn-icon" onclick="removeItem(this)"><i class="bi bi-trash"></i></button></td>
    `;
    tbody.appendChild(tr);
    itemIndex++;
    calculateTotal();
}

function removeItem(btn) {
    btn.closest('tr').remove();
    calculateTotal();
}

function productSelected(select, idx) {
    const tr = select.closest('tr');
    const option = select.options[select.selectedIndex];
    if (option.value) {
        tr.querySelector('.item-desc').value = option.text;
        tr.querySelector('.item-price').value = option.dataset.price;
        tr.querySelector('.item-unit').value = option.dataset.unit;
        tr.querySelector('.item-tax').value = option.dataset.tax;
    }
    calculateTotal();
}

function calculateTotal() {
    let subtotal = 0;
    let totalTax = 0;
    
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr => {
        const qty = parseFloat(tr.querySelector('.item-qty').value) || 0;
        const price = parseFloat(tr.querySelector('.item-price').value) || 0;
        const taxRate = parseFloat(tr.querySelector('.item-tax').value) || 0;
        
        const lineTotal = qty * price;
        const lineTax = lineTotal * (taxRate / 100);
        
        tr.querySelector('.item-total').value = lineTotal.toFixed(2);
        
        subtotal += lineTotal;
        totalTax += lineTax;
    });
    
    const discType = document.getElementById('discountType').value;
    const discVal = parseFloat(document.getElementById('discountValue').value) || 0;
    let discAmount = discType === 'percent' ? (subtotal * (discVal / 100)) : discVal;
    
    const grandTotal = (subtotal - discAmount) + totalTax;
    
    document.getElementById('calcSubtotal').textContent = '₹ ' + subtotal.toFixed(2);
    document.getElementById('calcTax').textContent = '₹ ' + totalTax.toFixed(2);
    document.getElementById('calcTotal').textContent = '₹ ' + grandTotal.toFixed(2);
}

// Add first item automatically
document.addEventListener('DOMContentLoaded', () => {
    if(document.querySelectorAll('#itemsTable tbody tr').length === 0) {
        addItem();
    }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body></html>
