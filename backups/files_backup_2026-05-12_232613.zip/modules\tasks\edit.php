<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM tasks WHERE id=?");
$stmt->execute([$id]);
$t = $stmt->fetch();
if (!$t) { setFlash('danger','Task not found.'); header('Location: '.BASE_URL.'/modules/tasks/index.php'); exit; }

$pageTitle = 'Edit Task';
$errors = [];
$users = db()->query("SELECT id, name FROM users ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $assigned_to = (int)($_POST['assigned_to'] ?? 0) ?: null;
    $priority = sanitize($_POST['priority'] ?? 'medium');
    $status = sanitize($_POST['status'] ?? 'pending');
    $due_date = sanitize($_POST['due_date'] ?? '');
    
    $related_module = sanitize($_POST['related_module'] ?? '') ?: null;
    $related_id = (int)($_POST['related_id'] ?? 0) ?: null;

    if (!$title) $errors['title'] = 'Task title is required.';

    if (!$errors) {
        $completed_at = ($status === 'completed' && $t['status'] !== 'completed') ? date('Y-m-d H:i:s') : $t['completed_at'];

        $stmt = db()->prepare("UPDATE tasks SET title=?, description=?, assigned_to=?, priority=?, status=?, due_date=?, related_module=?, related_id=?, completed_at=? WHERE id=?");
        $stmt->execute([$title, $description, $assigned_to, $priority, $status, $due_date?:null, $related_module, $related_id, $completed_at, $id]);
        
        logActivity('tasks','update',"Updated task: $title", $id);
        setFlash('success',"Task '$title' updated successfully.");
        header('Location: '.BASE_URL.'/modules/tasks/index.php');
        exit;
    }
}

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Edit Task</div>
</div>
<div class="page-content">
<div class="page-header">
  <div class="page-header-left"><h1>Edit Task</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/tasks/index.php">Tasks</a></li><li class="breadcrumb-item active">Edit</li></ol></nav>
  </div>
  <a href="<?= BASE_URL ?>/modules/tasks/index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="row">
  <div class="col-lg-8">
    <div class="crm-card">
      <div class="crm-card-body p-4">
        <form method="POST">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Task Title <span class="text-danger">*</span></label>
              <input type="text" name="title" class="form-control <?= isset($errors['title'])?'is-invalid':'' ?>" value="<?= e($t['title']) ?>" required>
              <?php if(isset($errors['title'])): ?><div class="invalid-feedback"><?= $errors['title'] ?></div><?php endif; ?>
            </div>
            
            <div class="col-12">
              <label class="form-label">Description</label>
              <textarea name="description" class="form-control" rows="4"><?= e($t['description']) ?></textarea>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Assign To</label>
              <select name="assigned_to" class="form-select">
                <option value="">— Unassigned —</option>
                <?php foreach($users as $u): ?>
                  <option value="<?= $u['id'] ?>" <?= $t['assigned_to']==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Due Date</label>
              <input type="date" name="due_date" class="form-control" value="<?= e($t['due_date']) ?>">
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Priority</label>
              <select name="priority" class="form-select">
                <option value="low" <?= $t['priority']==='low'?'selected':'' ?>>Low</option>
                <option value="medium" <?= $t['priority']==='medium'?'selected':'' ?>>Medium</option>
                <option value="high" <?= $t['priority']==='high'?'selected':'' ?>>High</option>
                <option value="urgent" <?= $t['priority']==='urgent'?'selected':'' ?>>Urgent</option>
              </select>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="pending" <?= $t['status']==='pending'?'selected':'' ?>>Pending</option>
                <option value="in_progress" <?= $t['status']==='in_progress'?'selected':'' ?>>In Progress</option>
                <option value="completed" <?= $t['status']==='completed'?'selected':'' ?>>Completed</option>
                <option value="cancelled" <?= $t['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
              </select>
            </div>

            <!-- Optional Relates To -->
            <div class="col-md-6">
              <label class="form-label">Related To Module (Optional)</label>
              <select name="related_module" class="form-select">
                <option value="">— None —</option>
                <option value="projects" <?= $t['related_module']==='projects'?'selected':'' ?>>Project</option>
                <option value="customers" <?= $t['related_module']==='customers'?'selected':'' ?>>Customer</option>
                <option value="leads" <?= $t['related_module']==='leads'?'selected':'' ?>>Lead</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Related ID</label>
              <input type="number" name="related_id" class="form-control" value="<?= e($t['related_id']) ?>" placeholder="e.g. Project ID">
            </div>

            <div class="col-12 mt-4 pt-3 border-top">
              <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Update Task</button>
              <a href="<?= BASE_URL ?>/modules/tasks/index.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
