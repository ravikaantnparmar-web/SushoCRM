<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
    exit;
}

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$task_id = (int)($_POST['task_id'] ?? 0);
$new_status = sanitize($_POST['status'] ?? '');

$valid_statuses = ['pending', 'in_progress', 'completed', 'cancelled'];

if (!$task_id || !in_array($new_status, $valid_statuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

try {
    $stmt = db()->prepare("SELECT * FROM tasks WHERE id = ?");
    $stmt->execute([$task_id]);
    $t = $stmt->fetch();
    
    if (!$t) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Task not found']);
        exit;
    }

    $completed_at = ($new_status === 'completed' && $t['status'] !== 'completed') ? date('Y-m-d H:i:s') : (($new_status !== 'completed') ? null : $t['completed_at']);

    $update = db()->prepare("UPDATE tasks SET status = ?, completed_at = ? WHERE id = ?");
    $update->execute([$new_status, $completed_at, $task_id]);

    logActivity('tasks', 'update', "Moved task '{$t['title']}' to $new_status via Kanban", $task_id);

    echo json_encode(['success' => true, 'message' => 'Task updated successfully']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
