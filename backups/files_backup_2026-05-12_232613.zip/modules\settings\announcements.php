<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireRole(['super_admin', 'admin']);

$pageTitle = 'Manage Communication Board';
$db = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $title = sanitize($_POST['title']);
        $content = $_POST['content'];
        $category = $_POST['category'];
        $priority = $_POST['priority'];
        
        $stmt = $db->prepare("INSERT INTO announcements (title, content, category, priority, created_by) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $content, $category, $priority, $_SESSION['user_id']]);
        setFlash('success', 'Announcement posted successfully.');
    } elseif ($_POST['action'] === 'toggle') {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("UPDATE announcements SET is_active = NOT is_active WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($_POST['action'] === 'delete') {
        $id = (int)$_POST['id'];
        $db->prepare("DELETE FROM announcements WHERE id = ?")->execute([$id]);
    }
    header('Location: announcements.php');
    exit;
}

$announcements = $db->query("SELECT a.*, u.name as author FROM announcements a LEFT JOIN users u ON a.created_by = u.id ORDER BY a.created_at DESC")->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Communication Board Settings</div>
</div>
<div class="page-content">
<?= flashHtml() ?>

<div class="page-header">
  <div class="page-header-left">
    <h1>Communication Board</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="index.php">Settings</a></li>
        <li class="breadcrumb-item active">Announcements</li>
      </ol>
    </nav>
  </div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal"><i class="bi bi-plus-lg me-1"></i>New Announcement</button>
</div>

<div class="table-wrapper">
  <table class="table crm-table mb-0">
    <thead>
      <tr>
        <th>Date</th>
        <th>Category</th>
        <th>Title</th>
        <th>Priority</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($announcements as $a): ?>
      <tr>
        <td><?= formatDate($a['created_at']) ?></td>
        <td><span class="badge bg-light text-dark border"><?= e($a['category']) ?></span></td>
        <td class="fw-bold"><?= e($a['title']) ?></td>
        <td>
            <span class="badge bg-<?= $a['priority']=='High'?'danger':($a['priority']=='Medium'?'warning':'info') ?>">
                <?= $a['priority'] ?>
            </span>
        </td>
        <td>
            <form method="POST" class="d-inline">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $a['is_active']?'btn-success':'btn-secondary' ?>">
                    <?= $a['is_active']?'Active':'Inactive' ?>
                </button>
            </form>
        </td>
        <td>
            <form method="POST" class="d-inline" onsubmit="return confirm('Delete this announcement?')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <button type="submit" class="btn btn-icon btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
            </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

</div></div>

<div class="modal fade" id="addAnnouncementModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <input type="hidden" name="action" value="add">
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold">New Announcement</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category" class="form-select" required>
              <option value="Announcement">Critical Announcement</option>
              <option value="Management Note">Daily Management Note</option>
              <option value="Policy Update">Policy Update</option>
              <option value="Target Reminder">Target Reminder</option>
              <option value="Operational Alert">Operational Alert</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" required placeholder="Quick summary...">
          </div>
          <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control" rows="5" required placeholder="Detailed message..."></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Priority</label>
            <select name="priority" class="form-select">
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Post Announcement</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
