<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/constants.php';
requireLogin();

$pageTitle = 'Leads Kanban';
$leadsByStatus = [];
foreach($leadStatuses as $st) $leadsByStatus[$st] = [];

$sql = "SELECT l.*, 
        (SELECT name FROM lead_contacts WHERE lead_id = l.id AND is_primary = 1 LIMIT 1) as contact_name
        FROM leads l 
        WHERE l.deleted_at IS NULL 
        ORDER BY l.created_at DESC";
$allLeads = db()->query($sql)->fetchAll();

foreach($allLeads as $l) {
    if (isset($leadsByStatus[$l['lead_status']])) {
        $leadsByStatus[$l['lead_status']][] = $l;
    } else {
        $leadsByStatus['Open'][] = $l; // Fallback
    }
}

include __DIR__ . '/../../includes/header.php'; ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>

<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Leads Kanban</div>
</div>

<div class="page-content">
    <div class="page-header">
        <div class="page-header-left">
            <h1>Leads Kanban</h1>
        </div>
        <div class="page-header-right">
            <div class="btn-group shadow-sm">
                <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-list-ul me-1"></i>Table</a>
                <button class="btn btn-outline-secondary active"><i class="bi bi-kanban me-1"></i>Kanban</button>
            </div>
            <a href="create.php" class="btn btn-primary shadow-sm"><i class="bi bi-plus-lg me-1"></i>Add Lead</a>
        </div>
    </div>

    <div class="kanban-board d-flex gap-3 overflow-auto pb-4" style="min-height: calc(100vh - 250px);">
        <?php foreach($leadStatuses as $st): ?>
        <div class="kanban-column" style="min-width: 300px; max-width: 300px;">
            <div class="kanban-column-header d-flex justify-content-between align-items-center mb-3">
                <h6 class="mb-0 fw-bold"><?= $st ?> <span class="badge bg-light text-dark ms-2"><?= count($leadsByStatus[$st]) ?></span></h6>
                <button class="btn btn-icon btn-sm"><i class="bi bi-three-dots-vertical"></i></button>
            </div>
            <div class="kanban-cards d-flex flex-column gap-2">
                <?php foreach($leadsByStatus[$st] as $l): ?>
                <div class="kanban-card crm-card p-3 shadow-sm border-left-<?= $l['lead_priority']=='Hot Lead'?'danger':'primary' ?>" style="cursor: grab;">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="x-small text-muted"><?= e($l['lead_code']) ?></span>
                        <?= statusBadge($l['lead_priority']) ?>
                    </div>
                    <div class="fw-bold mb-1"><a href="view.php?id=<?= $l['id'] ?>" class="text-dark"><?= e($l['company_name'] ?: 'No Company') ?></a></div>
                    <div class="small text-muted mb-3"><i class="bi bi-person me-1"></i><?= e($l['contact_name'] ?: '—') ?></div>
                    <div class="d-flex justify-content-between align-items-center mt-auto">
                        <div class="small text-muted"><i class="bi bi-calendar-event me-1"></i><?= formatDate($l['next_followup_date']) ?></div>
                        <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:24px; height:24px; font-size:10px;">
                            <?= strtoupper(substr($l['assigned_name'] ?? 'U', 0, 1)) ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</div>

<style>
.kanban-board::-webkit-scrollbar { height: 8px; }
.kanban-board::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
.kanban-card:hover { border-color: var(--primary); transform: translateY(-2px); transition: all 0.2s; }
.x-small { font-size: 10px; }
</style>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
