<?php
require 'config/db.php';
$stmt = db()->query('DESCRIBE expenses');
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
