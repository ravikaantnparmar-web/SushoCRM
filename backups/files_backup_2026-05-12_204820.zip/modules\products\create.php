<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
requireLogin();

$pageTitle = 'Add Product';
$errors = [];
$categories = db()->query("SELECT * FROM product_categories ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name          = sanitize($_POST['name'] ?? '');
    $sku           = sanitize($_POST['sku'] ?? '');
    $type          = sanitize($_POST['type'] ?? 'product');
    $category_id   = (int)($_POST['category_id'] ?? 0) ?: null;
    $unit          = sanitize($_POST['unit'] ?? 'Nos');
    $description   = sanitize($_POST['description'] ?? '');
    $purchase_price= (float)($_POST['purchase_price'] ?? 0);
    $selling_price = (float)($_POST['selling_price'] ?? 0);
    $tax_rate      = (float)($_POST['tax_rate'] ?? 18);
    $stock_qty     = (float)($_POST['stock_qty'] ?? 0);
    $min_stock     = (float)($_POST['min_stock'] ?? 0);
    $is_active     = isset($_POST['is_active']) ? 1 : 0;

    if (!$name)           $errors['name'] = 'Product name is required.';
    if ($selling_price < 0) $errors['selling_price'] = 'Price cannot be negative.';

    if ($sku) {
        $exists = db()->prepare("SELECT COUNT(*) FROM products WHERE sku=?");
        $exists->execute([$sku]);
        if ($exists->fetchColumn()) $errors['sku'] = 'SKU already exists.';
    }

    if (!$errors) {
        db()->prepare("INSERT INTO products (name, sku, type, category_id, unit, description, purchase_price, selling_price, tax_rate, stock_qty, min_stock, is_active, created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([$name,$sku?:null,$type,$category_id,$unit,$description,$purchase_price,$selling_price,$tax_rate,$stock_qty,$min_stock,$is_active,$_SESSION['user_id']]);
        $id = db()->lastInsertId();
        logActivity('products','create',"Created product: $name",$id);
        setFlash('success',"Product '$name' created.");
        header('Location: '.BASE_URL.'/modules/products/index.php');
        exit;
    }
}

include __DIR__ . '/../../includes/header.php';
?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php include __DIR__ . '/../../includes/sidebar.php'; ?>
<div class="main-content">
<div class="topbar">
  <button class="topbar-hamburger" id="hamburgerBtn"><i class="bi bi-list"></i></button>
  <div class="topbar-title">Add Product</div>
</div>
<div class="page-content">
<?= flashHtml() ?>
<div class="page-header">
  <div class="page-header-left"><h1>Add Product / Service</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/dashboard/index.php">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/modules/products/index.php">Products</a></li><li class="breadcrumb-item active">Add</li></ol></nav>
  </div>
  <a href="<?= BASE_URL ?>/modules/products/index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>
<form method="POST">
  <div class="row g-3">
    <div class="col-lg-8">
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-box-seam me-2"></i>Product Details</div>
        <div class="row g-3">
          <div class="col-md-8">
            <label class="form-label">Product Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control <?= isset($errors['name'])?'is-invalid':'' ?>" value="<?= e($_POST['name']??'') ?>" placeholder="e.g. HP Laptop 15s">
            <?php if(isset($errors['name'])): ?><div class="invalid-feedback"><?= $errors['name'] ?></div><?php endif; ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Type</label>
            <select name="type" class="form-select">
              <option value="product" <?= ($_POST['type']??'product')==='product'?'selected':'' ?>>Product</option>
              <option value="service" <?= ($_POST['type']??'')==='service'?'selected':'' ?>>Service</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">SKU / Code</label>
            <input type="text" name="sku" class="form-control <?= isset($errors['sku'])?'is-invalid':'' ?>" value="<?= e($_POST['sku']??'') ?>" placeholder="Leave blank to auto-assign">
            <?php if(isset($errors['sku'])): ?><div class="invalid-feedback"><?= $errors['sku'] ?></div><?php endif; ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
              <option value="">— Uncategorized —</option>
              <?php foreach($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($_POST['category_id']??'')==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Unit</label>
            <select name="unit" class="form-select">
              <?php foreach(['Nos','Pcs','Kg','Litre','Meter','Box','Set','Hour','Day','Month'] as $u): ?>
                <option value="<?= $u ?>" <?= ($_POST['unit']??'Nos')===$u?'selected':'' ?>><?= $u ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Tax Rate (%)</label>
            <select name="tax_rate" class="form-select">
              <?php foreach([0,5,12,18,28] as $t): ?>
                <option value="<?= $t ?>" <?= ($_POST['tax_rate']??18)==$t?'selected':'' ?>><?= $t ?>% <?= $t>0?'GST':'' ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Product description..."><?= e($_POST['description']??'') ?></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-currency-rupee me-2"></i>Pricing</div>
        <div class="mb-3">
          <label class="form-label">Purchase Price (₹)</label>
          <input type="number" name="purchase_price" class="form-control" value="<?= e($_POST['purchase_price']??'0') ?>" step="0.01" min="0">
        </div>
        <div class="mb-3">
          <label class="form-label">Selling Price (₹) <span class="text-danger">*</span></label>
          <input type="number" name="selling_price" class="form-control <?= isset($errors['selling_price'])?'is-invalid':'' ?>" value="<?= e($_POST['selling_price']??'0') ?>" step="0.01" min="0">
          <?php if(isset($errors['selling_price'])): ?><div class="invalid-feedback"><?= $errors['selling_price'] ?></div><?php endif; ?>
        </div>
      </div>
      <div class="crm-form-section">
        <div class="form-section-title"><i class="bi bi-boxes me-2"></i>Inventory</div>
        <div class="mb-3">
          <label class="form-label">Opening Stock Qty</label>
          <input type="number" name="stock_qty" class="form-control" value="<?= e($_POST['stock_qty']??'0') ?>" step="0.01" min="0">
        </div>
        <div class="mb-3">
          <label class="form-label">Minimum Stock Level</label>
          <input type="number" name="min_stock" class="form-control" value="<?= e($_POST['min_stock']??'0') ?>" step="0.01" min="0">
        </div>
        <div class="form-check mb-3">
          <input class="form-check-input" type="checkbox" name="is_active" id="isActive" value="1" <?= ($_POST['is_active']??1)?'checked':'' ?>>
          <label class="form-check-label" for="isActive">Active (visible in quotations/orders)</label>
        </div>
      </div>
      <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Save Product</button>
        <a href="<?= BASE_URL ?>/modules/products/index.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </div>
  </div>
</form>
</div></div></div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
