<?php
$currentPath = $_SERVER['PHP_SELF'];
function isActive(string $path): string {
    return strpos($_SERVER['PHP_SELF'], $path) !== false ? 'active' : '';
}
$user = currentUser();
?>
<nav class="sidebar" id="sidebar">
  <!-- Brand -->
  <div class="sidebar-brand">
    <div class="brand-logo">
      <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="Logo" style="width: 100%; height: 100%; object-fit: contain;">
    </div>
    <div class="brand-text">
      <span class="brand-name"><?= APP_NAME ?></span>
      <span class="brand-tagline"><?= APP_TAGLINE ?></span>
    </div>
    <button class="sidebar-toggle-btn d-lg-none" id="sidebarClose"><i class="bi bi-x-lg"></i></button>
  </div>

  <!-- User Card -->
  <div class="sidebar-user">
    <div class="sidebar-user-avatar">
      <?php if (!empty($user['avatar'])): ?>
        <img src="<?= BASE_URL ?>/<?= e($user['avatar']) ?>" alt="Avatar">
      <?php else: ?>
        <span><?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?></span>
      <?php endif; ?>
    </div>
    <div class="sidebar-user-info">
      <span class="user-name"><?= e($user['name'] ?? 'User') ?></span>
      <span class="user-role"><?= ucwords(str_replace('_', ' ', $user['role_slug'] ?? '')) ?></span>
    </div>
  </div>

  <div class="sidebar-menu">
    <!-- Dashboard -->
    <div class="menu-section">
      <a href="<?= BASE_URL ?>/modules/dashboard/index.php" class="menu-item <?= isActive('/dashboard/') ?>">
        <i class="bi bi-speedometer2"></i><span>Dashboard</span>
      </a>
    </div>

    <!-- CRM -->
    <div class="menu-section">
      <div class="menu-section-title">CRM</div>
      <a href="<?= BASE_URL ?>/modules/prospects/index.php" class="menu-item <?= isActive('/prospects/') ?>">
        <i class="bi bi-funnel-fill"></i><span>Prospects & Leads</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/customers/index.php" class="menu-item <?= isActive('/customers/') ?>">
        <i class="bi bi-people-fill"></i><span>Customers</span>
      </a>
    </div>

    <!-- Sales -->
    <div class="menu-section">
      <div class="menu-section-title">Sales</div>
      <a href="<?= BASE_URL ?>/modules/quotations/index.php" class="menu-item <?= isActive('/quotations/') ?>">
        <i class="bi bi-file-text-fill"></i><span>Quotations</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/orders/index.php" class="menu-item <?= isActive('/orders/') ?>">
        <i class="bi bi-cart-fill"></i><span>Orders</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/invoices/index.php" class="menu-item <?= isActive('/invoices/') ?>">
        <i class="bi bi-receipt-cutoff"></i><span>Invoices</span>
      </a>
    </div>

    <!-- Inventory -->
    <div class="menu-section">
      <div class="menu-section-title">Inventory</div>
      <a href="<?= BASE_URL ?>/modules/products/index.php" class="menu-item <?= isActive('/products/') ?>">
        <i class="bi bi-box-seam-fill"></i><span>Products & Services</span>
      </a>
    </div>

    <!-- Purchases -->
    <div class="menu-section">
      <div class="menu-section-title">Purchase</div>
      <a href="<?= BASE_URL ?>/modules/vendors/index.php" class="menu-item <?= isActive('/vendors/') ?>">
        <i class="bi bi-truck"></i><span>Vendors</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/purchases/index.php" class="menu-item <?= isActive('/purchases/') ?>">
        <i class="bi bi-bag-fill"></i><span>Purchases</span>
      </a>
    </div>

    <!-- Work Management -->
    <div class="menu-section">
      <div class="menu-section-title">Work Management</div>
      <a href="<?= BASE_URL ?>/modules/projects/index.php" class="menu-item <?= isActive('/projects/') ?>">
        <i class="bi bi-briefcase"></i><span>Projects</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/tasks/kanban.php" class="menu-item <?= isActive('/tasks/kanban') ?>">
        <i class="bi bi-kanban"></i><span>Kanban Board</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/tasks/index.php" class="menu-item <?= isActive('/tasks/index') ?>">
        <i class="bi bi-list-task"></i><span>Tasks</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/travels/index.php" class="menu-item <?= isActive('/travels/') ?>">
        <i class="bi bi-airplane-fill"></i><span>Travel & Visits</span>
      </a>
    </div>

    <!-- Finance -->
    <div class="menu-section">
      <div class="menu-section-title">Finance</div>
      <a href="<?= BASE_URL ?>/modules/payments/index.php" class="menu-item <?= isActive('/payments/') ?>">
        <i class="bi bi-wallet2"></i><span>Invoice Payments</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/receipts/index.php" class="menu-item <?= isActive('/receipts/') ?>">
        <i class="bi bi-receipt"></i><span>Receipts</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/expenses/index.php" class="menu-item <?= isActive('/expenses/') ?>">
        <i class="bi bi-cash-stack"></i><span>Expenses</span>
      </a>
    </div>

    <!-- HR -->
    <div class="menu-section">
      <div class="menu-section-title">HR</div>
      <a href="<?= BASE_URL ?>/modules/employees/index.php" class="menu-item <?= isActive('/employees/') ?>">
        <i class="bi bi-person-badge-fill"></i><span>Employees</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/attendance/index.php" class="menu-item <?= isActive('/attendance/') ?>">
        <i class="bi bi-calendar-check"></i><span>Attendance</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/salary/index.php" class="menu-item <?= isActive('/salary/') ?>">
        <i class="bi bi-currency-exchange"></i><span>Salary Management</span>
      </a>
    </div>

    <!-- Reports -->
    <div class="menu-section">
      <div class="menu-section-title">Analytics</div>
      <a href="<?= BASE_URL ?>/modules/reports/index.php" class="menu-item <?= isActive('/reports/') ?>">
        <i class="bi bi-bar-chart-fill"></i><span>Reports</span>
      </a>
    </div>

    <!-- Settings (Admin only) -->
    <?php if (isAdmin()): ?>
    <div class="menu-section">
      <div class="menu-section-title">Admin</div>
      <a href="<?= BASE_URL ?>/modules/settings/users.php" class="menu-item <?= isActive('/settings/users') ?>">
        <i class="bi bi-person-gear"></i><span>Users</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/settings/announcements.php" class="menu-item <?= isActive('/settings/announcements') ?>">
        <i class="bi bi-megaphone-fill"></i><span>Comm. Board</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/settings/index.php" class="menu-item <?= isActive('/settings/index') ?>">
        <i class="bi bi-gear-fill"></i><span>Settings</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/settings/backup.php" class="menu-item <?= isActive('/settings/backup') ?>">
        <i class="bi bi-shield-check"></i><span>System Backup</span>
      </a>
      <a href="<?= BASE_URL ?>/modules/settings/activity-logs.php" class="menu-item <?= isActive('/activity-logs') ?>">
        <i class="bi bi-clock-history"></i><span>Activity Logs</span>
      </a>
    </div>
    <?php endif; ?>
  </div>

  <!-- Security & Logout -->
  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>/modules/auth/change-password.php" class="menu-item <?= isActive('/auth/change-password') ?>">
      <i class="bi bi-shield-lock"></i><span>Change Password</span>
    </a>
    <a href="<?= BASE_URL ?>/modules/auth/logout.php" class="menu-item menu-item-logout">
      <i class="bi bi-box-arrow-left"></i><span>Logout</span>
    </a>
  </div>
</nav>
