<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Already logged in → redirect
if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/modules/dashboard/index.php');
    exit;
}

$error = '';
$timeout = isset($_GET['timeout']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF check
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please refresh and try again.';
    } else {
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = 'Please enter your email and password.';
        } else {
            $stmt = db()->prepare("SELECT u.*, r.slug AS role_slug FROM users u JOIN roles r ON u.role_id=r.id WHERE u.email = ? AND u.is_active = 1 LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Check lockout
                if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
                    $mins = ceil((strtotime($user['locked_until']) - time()) / 60);
                    $error = "Account locked. Try again in {$mins} minute(s).";
                } elseif (!password_verify($password, $user['password'])) {
                    $attempts = $user['login_attempts'] + 1;
                    if ($attempts >= MAX_LOGIN_ATTEMPTS) {
                        $lockedUntil = date('Y-m-d H:i:s', time() + LOCKOUT_DURATION);
                        db()->prepare("UPDATE users SET login_attempts=?, locked_until=? WHERE id=?")->execute([$attempts, $lockedUntil, $user['id']]);
                        $error = 'Too many failed attempts. Account locked for 15 minutes.';
                    } else {
                        db()->prepare("UPDATE users SET login_attempts=? WHERE id=?")->execute([$attempts, $user['id']]);
                        $remaining = MAX_LOGIN_ATTEMPTS - $attempts;
                        $error = "Invalid password. {$remaining} attempt(s) remaining.";
                    }
                } else {
                    // Success
                    require_once __DIR__ . '/../../includes/auth.php';
                    loginUser($user);
                    logActivity('auth', 'login', 'User logged in: ' . $user['email']);
                    header('Location: ' . BASE_URL . '/modules/dashboard/index.php');
                    exit;
                }
            } else {
                $error = 'No active account found with this email.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <!-- Logo -->
    <div class="text-center mb-4">
      <div class="login-logo">
        <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="Logo" style="width: 100%; height: 100%; object-fit: contain;">
      </div>
      <h1 class="h4 fw-bold text-white mt-3"><?= APP_NAME ?></h1>
      <p class="text-white-50 small"><?= APP_TAGLINE ?></p>
    </div>

    <?php if ($timeout): ?>
      <div class="alert alert-warning text-center py-2 small">Session expired. Please log in again.</div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-danger d-flex align-items-center gap-2 py-2">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <span class="small"><?= e($error) ?></span>
      </div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <?= csrfField() ?>
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <div class="input-group">
          <span class="input-group-text bg-transparent border-end-0" style="border-color:rgba(255,255,255,.12);color:rgba(255,255,255,.5)"><i class="bi bi-envelope"></i></span>
          <input type="email" name="email" class="form-control border-start-0" placeholder="you@company.com"
                 value="<?= e($_POST['email'] ?? '') ?>" required autocomplete="email" style="border-color:rgba(255,255,255,.12)">
        </div>
      </div>
      <div class="mb-4">
        <div class="d-flex justify-content-between">
          <label class="form-label">Password</label>
          <a href="<?= BASE_URL ?>/modules/auth/forgot-password.php" class="small text-primary">Forgot password?</a>
        </div>
        <div class="input-group">
          <span class="input-group-text bg-transparent border-end-0" style="border-color:rgba(255,255,255,.12);color:rgba(255,255,255,.5)"><i class="bi bi-lock"></i></span>
          <input type="password" name="password" id="passwordInput" class="form-control border-start-0 border-end-0"
                 placeholder="••••••••" required autocomplete="current-password" style="border-color:rgba(255,255,255,.12)">
          <button type="button" class="input-group-text bg-transparent border-start-0"
                  style="border-color:rgba(255,255,255,.12);color:rgba(255,255,255,.5)"
                  onclick="togglePwd()"><i class="bi bi-eye" id="eyeIcon"></i></button>
        </div>
      </div>
      <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
        <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
      </button>
    </form>



    <p class="text-center text-white-50 small mt-4 mb-0">&copy; <?= date('Y') ?> <?= COMPANY_NAME ?></p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePwd() {
  const inp = document.getElementById('passwordInput');
  const ico = document.getElementById('eyeIcon');
  if (inp.type === 'password') {
    inp.type = 'text';
    ico.className = 'bi bi-eye-slash';
  } else {
    inp.type = 'password';
    ico.className = 'bi bi-eye';
  }
}
</script>
</body>
</html>
